import React from 'react'

export default function AdminHeader() {
  return (
    <div>AdminHeader</div>
  )
}
