import MuiButton from "@/common/MaterialUi/MuiButton";
import Link from "next/link";
import React from "react";

export default function HeaderUnAuth() {
  return (
    <>
      <Link href="/auth/signup" className="w-fit">
        <MuiButton className="hover:scale-105 transition-all hover:gap-x-4">
          Signup
        </MuiButton>
      </Link>

      <Link href="/auth/signin" className="w-fit">
        <MuiButton className="hover:scale-105 transition-all hover:gap-x-4">
          Signin
        </MuiButton>
      </Link>
    </>
  );
}
