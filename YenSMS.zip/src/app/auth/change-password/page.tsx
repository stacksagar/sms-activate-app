import React from "react";

export default function ChangePassword() {
  return <div>ChangePassword</div>;
}
