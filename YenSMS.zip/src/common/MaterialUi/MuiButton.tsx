import React from "react";
import { Button } from "@mui/material";

interface Props extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  children: React.ReactNode;
  loading?: boolean;
  size?: "medium" | "small" | "large";
  color?:
    | "inherit"
    | "primary"
    | "secondary"
    | "success"
    | "error"
    | "info"
    | "warning";
  variant?: "text" | "outlined" | "contained";
}

export default function MuiButton({
  children,
  loading,
  size,
  color,
  variant,
  ...buttonProps
}: Props) {
  return (
    <Button
      className="w-full"
      variant={variant || "contained"}
      size={size || "large"}
      color={color || "primary"}
      {...buttonProps}
    >
      <span></span>
      <span className="flex items-center gap-x-2 whitespace-nowrap group">
        {children}
      </span>
      {loading ? (
        <span className="block ml-2 sm:ml-4 w-4 h-4 sm:w-5 sm:h-5 rounded-full animate-spin border-[2.5px] border-r-transparent"></span>
      ) : (
        <span> </span>
      )}
    </Button>
  );
}
