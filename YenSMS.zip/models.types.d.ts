interface UserT {
  id: string;
  name: string;
  phone?: string;
  email: string;
  password: string;
  balance: number;
}
