exports.id = 9056;
exports.ids = [9056];
exports.modules = {

/***/ 77087:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 31232, 23));
Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 52987, 23));
Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 56926, 23));
Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 50831, 23));
Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 44282, 23))

/***/ }),

/***/ 59982:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 8097));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 52949));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 8870))

/***/ }),

/***/ 35303:
/***/ (() => {



/***/ }),

/***/ 8097:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ Providers)
});

// EXTERNAL MODULE: external "next/dist/compiled/react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(56786);
// EXTERNAL MODULE: external "next/dist/compiled/react"
var react_ = __webpack_require__(18038);
// EXTERNAL MODULE: ./src/redux/redux_store.ts
var redux_store = __webpack_require__(10);
// EXTERNAL MODULE: ./node_modules/react-redux/lib/index.js
var lib = __webpack_require__(8250);
;// CONCATENATED MODULE: ./src/context/AuthProvider.tsx


const AuthContext = /*#__PURE__*/ (0,react_.createContext)({});
function AuthProvider({ children }) {
    const [auth, setAuth] = (0,react_.useState)();
    const [error, setError] = (0,react_.useState)("");
    const [persist, setPersist] = (0,react_.useState)(false);
    const [loading, setLoading] = (0,react_.useState)(false);
    return /*#__PURE__*/ jsx_runtime_.jsx(AuthContext.Provider, {
        value: {
            auth,
            setAuth,
            persist,
            setPersist,
            loading,
            setLoading,
            error,
            setError
        },
        children: children
    });
}
function useAuth() {
    return useContext(AuthContext);
}

// EXTERNAL MODULE: ./src/context/ThemeProvider.tsx
var ThemeProvider = __webpack_require__(28942);
;// CONCATENATED MODULE: ./src/context/ContextProvider.tsx
/* __next_internal_client_entry_do_not_use__ default auto */ 


const ContextProvider = ({ children })=>{
    return /*#__PURE__*/ jsx_runtime_.jsx(ThemeProvider/* default */.Z, {
        children: /*#__PURE__*/ jsx_runtime_.jsx(AuthProvider, {
            children: children
        })
    });
};
/* harmony default export */ const context_ContextProvider = (ContextProvider);

// EXTERNAL MODULE: ./node_modules/@mui/material/node/styles/index.js
var styles = __webpack_require__(83476);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/CssBaseline/index.js
var CssBaseline = __webpack_require__(98331);
// EXTERNAL MODULE: ./node_modules/@emotion/cache/dist/emotion-cache.esm.js + 8 modules
var emotion_cache_esm = __webpack_require__(63676);
// EXTERNAL MODULE: ./node_modules/next/navigation.js
var navigation = __webpack_require__(57114);
// EXTERNAL MODULE: ./node_modules/@emotion/react/dist/emotion-element-6bdfffb2.esm.js + 1 modules
var emotion_element_6bdfffb2_esm = __webpack_require__(7904);
;// CONCATENATED MODULE: ./src/components/MaterialTheme/EmotionCache.tsx
/* __next_internal_client_entry_do_not_use__ default auto */ 




// Adapted from https://github.com/garronej/tss-react/blob/main/src/next/appDir.tsx
function NextAppDirEmotionCacheProvider(props) {
    const { options, CacheProvider = emotion_element_6bdfffb2_esm.C, children } = props;
    const [registry] = react_.useState(()=>{
        const cache = (0,emotion_cache_esm["default"])(options);
        cache.compat = true;
        const prevInsert = cache.insert;
        let inserted = [];
        cache.insert = (...args)=>{
            const [selector, serialized] = args;
            if (cache.inserted[serialized.name] === undefined) {
                inserted.push({
                    name: serialized.name,
                    isGlobal: !selector
                });
            }
            return prevInsert(...args);
        };
        const flush = ()=>{
            const prevInserted = inserted;
            inserted = [];
            return prevInserted;
        };
        return {
            cache,
            flush
        };
    });
    (0,navigation.useServerInsertedHTML)(()=>{
        const inserted = registry.flush();
        if (inserted.length === 0) {
            return null;
        }
        let styles = "";
        let dataEmotionAttribute = registry.cache.key;
        const globals = [];
        inserted.forEach(({ name, isGlobal })=>{
            const style = registry.cache.inserted[name];
            if (typeof style !== "boolean") {
                if (isGlobal) {
                    globals.push({
                        name,
                        style
                    });
                } else {
                    styles += style;
                    dataEmotionAttribute += ` ${name}`;
                }
            }
        });
        return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(react_.Fragment, {
            children: [
                globals.map(({ name, style })=>/*#__PURE__*/ jsx_runtime_.jsx("style", {
                        "data-emotion": `${registry.cache.key}-global ${name}`,
                        // eslint-disable-next-line react/no-danger
                        dangerouslySetInnerHTML: {
                            __html: style
                        }
                    }, name)),
                styles && /*#__PURE__*/ jsx_runtime_.jsx("style", {
                    "data-emotion": dataEmotionAttribute,
                    // eslint-disable-next-line react/no-danger
                    dangerouslySetInnerHTML: {
                        __html: styles
                    }
                })
            ]
        });
    });
    return /*#__PURE__*/ jsx_runtime_.jsx(CacheProvider, {
        value: registry.cache,
        children: children
    });
}

// EXTERNAL MODULE: ./node_modules/@mui/material/node/index.js
var node = __webpack_require__(17421);
// EXTERNAL MODULE: ./node_modules/js-cookie/dist/js.cookie.mjs
var js_cookie = __webpack_require__(72479);
;// CONCATENATED MODULE: ./src/components/MaterialTheme/MaterialThemeProvider.tsx
/* __next_internal_client_entry_do_not_use__ default auto */ 







function MaterialThemeProvider({ children }) {
    const { theme } = (0,ThemeProvider/* useTheme */.F)();
    return /*#__PURE__*/ jsx_runtime_.jsx(NextAppDirEmotionCacheProvider, {
        options: {
            key: "mui"
        },
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(styles.ThemeProvider, {
            theme: (0,node.createTheme)({
                palette: {
                    mode: theme || js_cookie/* default */.Z.get("theme") || "light",
                    background: {
                        paper: theme === "dark" ? "#0f172a" : "#ffffff",
                        default: theme === "dark" ? "#020617" : "#ffffff"
                    }
                }
            }),
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx(CssBaseline["default"], {}),
                children
            ]
        })
    });
}

// EXTERNAL MODULE: ./node_modules/react-toastify/dist/react-toastify.esm.mjs
var react_toastify_esm = __webpack_require__(34751);
// EXTERNAL MODULE: ./node_modules/react-toastify/dist/ReactToastify.css
var ReactToastify = __webpack_require__(45996);
// EXTERNAL MODULE: ./node_modules/next-auth/react/index.js
var react = __webpack_require__(74284);
;// CONCATENATED MODULE: ./src/app/Providers.tsx
/* __next_internal_client_entry_do_not_use__ default auto */ 








function Providers({ children }) {
    return /*#__PURE__*/ jsx_runtime_.jsx(react.SessionProvider, {
        children: /*#__PURE__*/ jsx_runtime_.jsx(context_ContextProvider, {
            children: /*#__PURE__*/ jsx_runtime_.jsx(MaterialThemeProvider, {
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(lib.Provider, {
                    store: redux_store/* default */.ZP,
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx(react_toastify_esm/* ToastContainer */.Ix, {
                            position: "top-center",
                            closeOnClick: true,
                            pauseOnFocusLoss: true,
                            draggable: true,
                            pauseOnHover: true
                        }),
                        children
                    ]
                })
            })
        })
    });
}


/***/ }),

/***/ 42635:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (/* binding */ FIcon)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(56786);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _fortawesome_free_brands_svg_icons__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(42900);
/* harmony import */ var _fortawesome_free_solid_svg_icons__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(42050);
/* harmony import */ var _fortawesome_react_fontawesome__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(52196);
/* harmony import */ var _fortawesome_react_fontawesome__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_fortawesome_react_fontawesome__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(18038);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* __next_internal_client_entry_do_not_use__ default auto */ 




function FIcon({ icon, ...all }) {
    const iconString = icon;
    const [Icon, setIcon] = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)();
    (0,react__WEBPACK_IMPORTED_MODULE_2__.useEffect)(()=>{
        const words = iconString.split("-");
        function makeFirstCharUppercase(s) {
            return s.substring(0, 1).toUpperCase() + s.substring(1);
        }
        const CapitilizeString = words.reduce((acc, val)=>{
            return acc + makeFirstCharUppercase(val);
        }, "");
        const SolidIcons = _fortawesome_free_solid_svg_icons__WEBPACK_IMPORTED_MODULE_3__;
        const BrandIcons = _fortawesome_free_brands_svg_icons__WEBPACK_IMPORTED_MODULE_4__;
        const fullIconName = "fa" + CapitilizeString;
        setIcon(SolidIcons[fullIconName] || BrandIcons[fullIconName]);
    }, [
        iconString
    ]);
    if (!Icon) return null;
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_fortawesome_react_fontawesome__WEBPACK_IMPORTED_MODULE_1__.FontAwesomeIcon, {
        ...all,
        icon: Icon
    });
}


/***/ }),

/***/ 86011:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (/* binding */ MuiButton)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(56786);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(18038);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(17421);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_2__);



function MuiButton({ children, loading, size, color, variant, ...buttonProps }) {
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Button, {
        className: "w-full",
        variant: variant || "contained",
        size: size || "large",
        color: color || "primary",
        ...buttonProps,
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {}),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                className: "flex items-center gap-x-2 whitespace-nowrap group",
                children: children
            }),
            loading ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                className: "block ml-2 sm:ml-4 w-4 h-4 sm:w-5 sm:h-5 rounded-full animate-spin border-[2.5px] border-r-transparent"
            }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                children: " "
            })
        ]
    });
}


/***/ }),

/***/ 17317:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (/* binding */ TextLogo)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(56786);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(18038);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _FIcon__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(42635);



function TextLogo() {
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: "flex w-fit items-center justify-around gap-2",
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "-rotate-12 transform text-2xl text-purple-600 dark:text-white",
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_FIcon__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                    icon: "mobile-screen"
                })
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "space-x-1 border-r-2 border-t-2 border-b-2 border-purple-600 py-1 pr-2 text-2xl font-bold tracking-wider dark:border-white",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                        className: "text-blue-600 dark:text-blue-300",
                        children: "YEN"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                        className: "text-purple-600 dark:text-white font-extrabold",
                        children: "SMS"
                    })
                ]
            })
        ]
    });
}


/***/ }),

/***/ 8870:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ ClientFooter)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(56786);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _common_FIcon__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(42635);
/* harmony import */ var _common_TextLogo__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(17317);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(11440);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(18038);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_4__);
/* __next_internal_client_entry_do_not_use__ default auto */ 




function ClientFooter() {
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("footer", {
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
            children: "footer text"
        })
    });
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("footer", {
        className: "py-20 hidden",
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "container py-8 flex flex-col md:flex-row items-center justify-between  gap-6",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_common_TextLogo__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {}),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "flex items-center gap-1 xl:gap-6 text-lg flex-col md:flex-row",
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("a", {
                                href: `mailto:${"address"}`,
                                className: "flex gap-x-1",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_common_FIcon__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z, {
                                            icon: "envelope"
                                        })
                                    }),
                                    "Send us an e-mail"
                                ]
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("a", {
                                href: `mailto:${"address"}`,
                                className: "flex gap-x-1",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_common_FIcon__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z, {
                                            icon: "contact-book"
                                        })
                                    }),
                                    "If you need help, open a ticket"
                                ]
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "container py-8 border-t",
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "flex flex-col-reverse md:flex-row items-center justify-between",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                            className: "block text-lg text-gray-500 sm:text-center dark:text-gray-400",
                            children: "\xa9YenSMS 2023 All Rights Reserved."
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: "flex items-center justify-center xl:justify-end flex-wrap gap-1 md:gap-2 xl:gap-5",
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_3___default()), {
                                    href: "/blog",
                                    className: "hover:underline text-lg hover:text-blue-500 ",
                                    children: "Blog"
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_3___default()), {
                                    href: "/contact",
                                    className: "hover:underline text-lg hover:text-blue-500",
                                    children: "Contact"
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_3___default()), {
                                    href: "/privacy-policy",
                                    className: "hover:underline text-lg hover:text-blue-500",
                                    children: "Privacy Policy"
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_3___default()), {
                                    href: "/terms-of-service",
                                    className: "hover:underline text-lg hover:text-blue-500 ",
                                    children: "Terms of Service"
                                })
                            ]
                        })
                    ]
                })
            })
        ]
    });
}


/***/ }),

/***/ 52949:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ ClientHeader)
});

// EXTERNAL MODULE: external "next/dist/compiled/react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(56786);
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(52451);
var image_default = /*#__PURE__*/__webpack_require__.n(next_image);
// EXTERNAL MODULE: external "next/dist/compiled/react"
var react_ = __webpack_require__(18038);
// EXTERNAL MODULE: ./node_modules/@headlessui/react/dist/components/dialog/dialog.js + 31 modules
var dialog = __webpack_require__(50608);
// EXTERNAL MODULE: ./node_modules/@heroicons/react/24/outline/esm/Bars3Icon.js
var Bars3Icon = __webpack_require__(46140);
// EXTERNAL MODULE: ./node_modules/@heroicons/react/24/outline/esm/XMarkIcon.js
var XMarkIcon = __webpack_require__(57048);
// EXTERNAL MODULE: ./node_modules/framer-motion/dist/es/render/dom/motion.mjs + 149 modules
var motion = __webpack_require__(81110);
// EXTERNAL MODULE: ./src/context/ThemeProvider.tsx
var ThemeProvider = __webpack_require__(28942);
;// CONCATENATED MODULE: ./src/common/ThemeToggler.tsx
/* __next_internal_client_entry_do_not_use__ default auto */ 



function ThemeToggler() {
    const { theme, setTheme } = (0,ThemeProvider/* useTheme */.F)();
    function toggle() {
        setTheme((p)=>p === "dark" ? "light" : "dark");
    }
    return /*#__PURE__*/ jsx_runtime_.jsx(motion/* motion */.E.button, {
        whileHover: {
            scale: 1.2
        },
        whileTap: {
            scale: 0.8
        },
        className: "cursor-pointer bg-white text-black shadow p-2 rounded-full",
        onClick: toggle,
        children: /*#__PURE__*/ jsx_runtime_.jsx("span", {
            children: theme === "dark" ? /*#__PURE__*/ jsx_runtime_.jsx("svg", {
                xmlns: "http://www.w3.org/2000/svg",
                width: "20",
                height: "20",
                viewBox: "0 0 24 24",
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("g", {
                    fill: "none",
                    fillRule: "evenodd",
                    transform: "translate(-444 -204)",
                    children: [
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("g", {
                            fill: "currentColor",
                            transform: "translate(354 144)",
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                    fillRule: "nonzero",
                                    d: "M108.5 24C108.5 27.5902136 105.590214 30.5 102 30.5 98.4097864 30.5 95.5 27.5902136 95.5 24 95.5 20.4097864 98.4097864 17.5 102 17.5 105.590214 17.5 108.5 20.4097864 108.5 24zM107 24C107 21.2382136 104.761786 19 102 19 99.2382136 19 97 21.2382136 97 24 97 26.7617864 99.2382136 29 102 29 104.761786 29 107 26.7617864 107 24zM101 12.75L101 14.75C101 15.1642136 101.335786 15.5 101.75 15.5 102.164214 15.5 102.5 15.1642136 102.5 14.75L102.5 12.75C102.5 12.3357864 102.164214 12 101.75 12 101.335786 12 101 12.3357864 101 12.75zM95.7255165 14.6323616L96.7485165 16.4038616C96.9556573 16.7625614 97.4143618 16.8854243 97.7730616 16.6782835 98.1317614 16.4711427 98.2546243 16.0124382 98.0474835 15.6537384L97.0244835 13.8822384C96.8173427 13.5235386 96.3586382 13.4006757 95.9999384 13.6078165 95.6412386 13.8149573 95.5183757 14.2736618 95.7255165 14.6323616zM91.8822384 19.0244835L93.6537384 20.0474835C94.0124382 20.2546243 94.4711427 20.1317614 94.6782835 19.7730616 94.8854243 19.4143618 94.7625614 18.9556573 94.4038616 18.7485165L92.6323616 17.7255165C92.2736618 17.5183757 91.8149573 17.6412386 91.6078165 17.9999384 91.4006757 18.3586382 91.5235386 18.8173427 91.8822384 19.0244835zM90.75 25L92.75 25C93.1642136 25 93.5 24.6642136 93.5 24.25 93.5 23.8357864 93.1642136 23.5 92.75 23.5L90.75 23.5C90.3357864 23.5 90 23.8357864 90 24.25 90 24.6642136 90.3357864 25 90.75 25zM92.6323616 30.2744835L94.4038616 29.2514835C94.7625614 29.0443427 94.8854243 28.5856382 94.6782835 28.2269384 94.4711427 27.8682386 94.0124382 27.7453757 93.6537384 27.9525165L91.8822384 28.9755165C91.5235386 29.1826573 91.4006757 29.6413618 91.6078165 30.0000616 91.8149573 30.3587614 92.2736618 30.4816243 92.6323616 30.2744835zM97.0244835 34.1177616L98.0474835 32.3462616C98.2546243 31.9875618 98.1317614 31.5288573 97.7730616 31.3217165 97.4143618 31.1145757 96.9556573 31.2374386 96.7485165 31.5961384L95.7255165 33.3676384C95.5183757 33.7263382 95.6412386 34.1850427 95.9999384 34.3921835 96.3586382 34.5993243 96.8173427 34.4764614 97.0244835 34.1177616zM103 35.25L103 33.25C103 32.8357864 102.664214 32.5 102.25 32.5 101.835786 32.5 101.5 32.8357864 101.5 33.25L101.5 35.25C101.5 35.6642136 101.835786 36 102.25 36 102.664214 36 103 35.6642136 103 35.25zM108.274483 33.3676384L107.251483 31.5961384C107.044343 31.2374386 106.585638 31.1145757 106.226938 31.3217165 105.868239 31.5288573 105.745376 31.9875618 105.952517 32.3462616L106.975517 34.1177616C107.182657 34.4764614 107.641362 34.5993243 108.000062 34.3921835 108.358761 34.1850427 108.481624 33.7263382 108.274483 33.3676384zM112.117762 28.9755165L110.346262 27.9525165C109.987562 27.7453757 109.528857 27.8682386 109.321717 28.2269384 109.114576 28.5856382 109.237439 29.0443427 109.596138 29.2514835L111.367638 30.2744835C111.726338 30.4816243 112.185043 30.3587614 112.392183 30.0000616 112.599324 29.6413618 112.476461 29.1826573 112.117762 28.9755165zM113.25 23L111.25 23C110.835786 23 110.5 23.3357864 110.5 23.75 110.5 24.1642136 110.835786 24.5 111.25 24.5L113.25 24.5C113.664214 24.5 114 24.1642136 114 23.75 114 23.3357864 113.664214 23 113.25 23zM111.367638 17.7255165L109.596138 18.7485165C109.237439 18.9556573 109.114576 19.4143618 109.321717 19.7730616 109.528857 20.1317614 109.987562 20.2546243 110.346262 20.0474835L112.117762 19.0244835C112.476461 18.8173427 112.599324 18.3586382 112.392183 17.9999384 112.185043 17.6412386 111.726338 17.5183757 111.367638 17.7255165zM106.975517 13.8822384L105.952517 15.6537384C105.745376 16.0124382 105.868239 16.4711427 106.226938 16.6782835 106.585638 16.8854243 107.044343 16.7625614 107.251483 16.4038616L108.274483 14.6323616C108.481624 14.2736618 108.358761 13.8149573 108.000062 13.6078165 107.641362 13.4006757 107.182657 13.5235386 106.975517 13.8822384z",
                                    transform: "translate(0 48)"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                    d: "M98.6123,60.1372 C98.6123,59.3552 98.8753,58.6427 99.3368,58.0942 C99.5293,57.8657 99.3933,57.5092 99.0943,57.5017 C99.0793,57.5012 99.0633,57.5007 99.0483,57.5007 C97.1578,57.4747 95.5418,59.0312 95.5008,60.9217 C95.4578,62.8907 97.0408,64.5002 98.9998,64.5002 C99.7793,64.5002 100.4983,64.2452 101.0798,63.8142 C101.3183,63.6372 101.2358,63.2627 100.9478,63.1897 C99.5923,62.8457 98.6123,61.6072 98.6123,60.1372",
                                    transform: "translate(3 11)"
                                })
                            ]
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("polygon", {
                            points: "444 228 468 228 468 204 444 204"
                        })
                    ]
                })
            }) : /*#__PURE__*/ jsx_runtime_.jsx("svg", {
                width: "20",
                height: "20",
                viewBox: "0 0 20 20",
                fill: "none",
                xmlns: "http://www.w3.org/2000/svg",
                children: /*#__PURE__*/ jsx_runtime_.jsx("path", {
                    d: "M8 4C8 8.4 11.6 12 16 12C17.4 12 18.8 11.6 20 11C19.5 16.1 15.2 20 10 20C4.5 20 0 15.5 0 10C0 4.8 4 0.5 9 0C8.4 1.2 8 2.6 8 4ZM2 10C2 14.4 5.6 18 10 18C12.9 18 15.5 16.5 17 14C16.7 14 16.4 14 16 14C10.5 14 6 9.5 6 4C6 3.7 6 3.4 6 3C3.6 4.4 2 7.1 2 10Z",
                    fill: "currentColor"
                })
            })
        })
    });
}

// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(11440);
var link_default = /*#__PURE__*/__webpack_require__.n(next_link);
// EXTERNAL MODULE: ./src/common/TextLogo.tsx
var TextLogo = __webpack_require__(17317);
// EXTERNAL MODULE: ./node_modules/next-auth/react/index.js
var react = __webpack_require__(74284);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/index.js
var node = __webpack_require__(17421);
;// CONCATENATED MODULE: ./src/components/client/header/HeaderAuth.tsx



function HeaderAuth() {
    const { data } = (0,react.useSession)();
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: "flex items-center gap-2",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(node.Button, {
                variant: "outlined",
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: "flex flex-col items-start gap-0 leading-4",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("span", {
                            className: "block max-w-[100px] truncate",
                            children: data?.user?.name
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("small", {
                            children: [
                                data?.user?.email === "bangladeshisoftware@gmail.com" ? 2505 : 0,
                                " ৳"
                            ]
                        })
                    ]
                })
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)(node.Button, {
                variant: "contained",
                color: "warning",
                onClick: ()=>(0,react.signOut)(),
                children: [
                    " ",
                    "Logout",
                    " "
                ]
            })
        ]
    });
}

// EXTERNAL MODULE: ./src/common/MaterialUi/MuiButton.tsx
var MuiButton = __webpack_require__(86011);
;// CONCATENATED MODULE: ./src/components/client/header/HeaderUnAuth.tsx




function HeaderUnAuth() {
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                href: "/auth/signup",
                className: "w-fit",
                children: /*#__PURE__*/ jsx_runtime_.jsx(MuiButton/* default */.Z, {
                    className: "hover:scale-105 transition-all hover:gap-x-4",
                    children: "Signup"
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                href: "/auth/signin",
                className: "w-fit",
                children: /*#__PURE__*/ jsx_runtime_.jsx(MuiButton/* default */.Z, {
                    className: "hover:scale-105 transition-all hover:gap-x-4",
                    children: "Signin"
                })
            })
        ]
    });
}

;// CONCATENATED MODULE: ./src/components/client/header/ClientHeader.tsx
/* __next_internal_client_entry_do_not_use__ default auto */ 










const navigation = [
    {
        name: "Features",
        href: "#features"
    },
    {
        name: "How It Work",
        href: "#how-it-works"
    },
    {
        name: "F.A.Q",
        href: "#faq"
    }
];
function ClientHeader() {
    const [mobileMenuOpen, setMobileMenuOpen] = (0,react_.useState)(false);
    const { data: session } = (0,react.useSession)();
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("header", {
        className: "z-50 border-b dark:border-b-gray-600",
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("nav", {
                className: "h-[80px] container flex items-center justify-between",
                "aria-label": "Global",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "flex lg:flex-1",
                        children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                            href: "/",
                            className: "-m-1.5 p-1.5",
                            children: /*#__PURE__*/ jsx_runtime_.jsx(TextLogo/* default */.Z, {})
                        })
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "flex lg:hidden items-center",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "flex items-center pr-5",
                                children: /*#__PURE__*/ jsx_runtime_.jsx(ThemeToggler, {})
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("button", {
                                type: "button",
                                className: "-m-2.5 inline-flex items-center justify-center rounded-md p-2.5 ",
                                onClick: ()=>setMobileMenuOpen(true),
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                        className: "sr-only",
                                        children: "Open main menu"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx(Bars3Icon/* default */.Z, {
                                        className: "h-6 w-6",
                                        "aria-hidden": "true"
                                    })
                                ]
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "hidden lg:flex lg:gap-x-12 items-center justify-end pr-10 w-full",
                        children: [
                            navigation.map((item)=>/*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                    href: item.href,
                                    className: "text-sm font-semibold leading-6 ",
                                    children: item.name
                                }, item.name)),
                            /*#__PURE__*/ jsx_runtime_.jsx(ThemeToggler, {})
                        ]
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "hidden lg:flex lg:flex-1 lg:justify-end gap-2",
                        children: session?.user?.name ? /*#__PURE__*/ jsx_runtime_.jsx(HeaderAuth, {}) : /*#__PURE__*/ jsx_runtime_.jsx(HeaderUnAuth, {})
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)(dialog/* Dialog */.V, {
                as: "div",
                className: "lg:hidden",
                open: mobileMenuOpen,
                onClose: setMobileMenuOpen,
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "fixed inset-0 z-50"
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)(dialog/* Dialog */.V.Panel, {
                        className: "fixed inset-y-0 right-0 z-50 w-full overflow-y-auto bg-white dark:bg-gray-900 px-6 py-6 sm:max-w-sm sm:ring-1 sm:ring-gray-900/10",
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "flex items-center justify-between",
                                children: [
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)((link_default()), {
                                        href: "/",
                                        className: "-m-1.5 p-1.5",
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                className: "sr-only",
                                                children: "Your Company"
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                                src: "/logo.svg",
                                                width: 44,
                                                height: 44,
                                                alt: "logo"
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("button", {
                                        type: "button",
                                        className: "-m-2.5 rounded-md p-2.5 ",
                                        onClick: ()=>setMobileMenuOpen(false),
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                className: "sr-only",
                                                children: "Close menu"
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx(XMarkIcon/* default */.Z, {
                                                className: "h-6 w-6",
                                                "aria-hidden": "true"
                                            })
                                        ]
                                    })
                                ]
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "mt-6 flow-root",
                                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    className: "-my-6 divide-y divide-gray-500/10",
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                            className: "space-y-2 py-6",
                                            children: navigation.map((item)=>/*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                    href: item.href,
                                                    className: "-mx-3 block rounded-lg px-3 py-2 text-base font-semibold leading-7  hover:bg-gray-50",
                                                    children: item.name
                                                }, item.name))
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                            className: "py-6 flex items-center gap-2",
                                            children: session?.user?.name ? /*#__PURE__*/ jsx_runtime_.jsx(HeaderAuth, {}) : /*#__PURE__*/ jsx_runtime_.jsx(HeaderUnAuth, {})
                                        })
                                    ]
                                })
                            })
                        ]
                    })
                ]
            })
        ]
    });
}


/***/ }),

/***/ 28942:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   F: () => (/* binding */ useTheme),
/* harmony export */   Z: () => (/* binding */ ThemeProvider)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(56786);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(18038);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var js_cookie__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(72479);



const ThemeContext = /*#__PURE__*/ (0,react__WEBPACK_IMPORTED_MODULE_1__.createContext)({});
function ThemeProvider({ children }) {
    const [theme, setTheme] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(js_cookie__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z.get("theme") || "light");
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        if (theme === "light") {
            document.documentElement.classList.remove("dark");
        } else {
            document.documentElement.classList.add("dark");
        }
        js_cookie__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z.set("theme", theme, {
            expires: 365.25
        });
    }, [
        theme
    ]);
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(ThemeContext.Provider, {
        value: {
            theme,
            setTheme
        },
        children: children
    });
}
function useTheme() {
    return (0,react__WEBPACK_IMPORTED_MODULE_1__.useContext)(ThemeContext);
}


/***/ }),

/***/ 3497:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   e: () => (/* binding */ activationActions)
/* harmony export */ });
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(91388);
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__);

const initialState = {
    data: [
        {
            id: 1,
            activationId: "1678177405",
            phoneNumber: "18652331277",
            country_logo: "https://smsactivate.s3.eu-central-1.amazonaws.com/assets/ico/country/187.svg",
            service_logo: "https://smsactivate.s3.eu-central-1.amazonaws.com/assets/ico/lf0.webp",
            time: "13 min",
            cost: 20,
            status: "STATUS_WAIT_CODE",
            sms_code: [
                "453453"
            ],
            sms_text: []
        },
        {
            id: 2,
            activationId: "1678259901",
            phoneNumber: "14257255007",
            time: "2023-08-20 12:40:40",
            operator: "any",
            cost: 30,
            canGetAnotherSms: false,
            status: "STATUS_WAIT_CODE",
            sms_code: [],
            sms_text: [],
            country_logo: "https://smsactivate.s3.eu-central-1.amazonaws.com/assets/ico/country/187.svg",
            service_logo: "https://smsactivate.s3.eu-central-1.amazonaws.com/assets/ico/fb0.webp"
        }
    ],
    loading: false,
    fetched: false,
    error: ""
};
const activationSlice = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createSlice)({
    name: "activations",
    initialState,
    reducers: {
        updateActivation (state, action) {
            if (!action.payload?.id) return;
            let index = -1;
            for(let i = 0; i < state.data.length; i++){
                if (state.data[i].id === action.payload?.id) {
                    index = i;
                    break;
                }
            }
            if (index < 0) return;
            state.data[index] = {
                ...state.data[index],
                ...action.payload.data
            };
        },
        updateActivations (state, action) {
            const activations = action.payload;
            if (!activations) return;
            for(let i = 0; i < state.data?.length; i++){
                for(let j = 0; j < activations?.length; j++){
                    const service = state.data[i];
                    const activeService = activations[j];
                    if (service.activationId === activeService.activationId) {
                        state.data[i].sms_code = activeService?.smsCode;
                        state.data[i].status = activeService?.smsCode?.length > 0 ? "COMPLETED" : "STATUS_WAIT_CODE";
                    } else {
                        if (state.data[i].status === "STATUS_WAIT_CODE") state.data[i].status = "STATUS_CANCEL";
                    }
                }
            }
        },
        cancelActivationsStatus (state) {
            for(let i = 0; i < state.data?.length; i++){
                if (state.data[i].status === "STATUS_WAIT_CODE") {
                    state.data[i].status = "STATUS_CANCEL";
                }
            }
        },
        addActivation (state, action) {
            state.data.unshift(action.payload);
        }
    },
    extraReducers: (builder)=>{}
});
const activationActions = activationSlice.actions;
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (activationSlice);


/***/ }),

/***/ 29440:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Q: () => (/* binding */ fetchServices),
/* harmony export */   t: () => (/* binding */ fetchCountries)
/* harmony export */ });
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(91388);
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__);

const fetchServices = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createAsyncThunk)("services/fetchServices", async (_params)=>{
    const response = await fetch(`/api/sms-active/getTopCountriesByService`);
    const data = await response.json();
    return data;
});
const fetchCountries = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createAsyncThunk)("services/fetchCountries", async (_params)=>{
    const response = await fetch(`/api/sms-active/getCountries`);
    const data = await response.json();
    return data;
});


/***/ }),

/***/ 29719:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  Z: () => (/* binding */ servicesSlice),
  C: () => (/* binding */ serviceActions)
});

// EXTERNAL MODULE: ./node_modules/@reduxjs/toolkit/dist/redux-toolkit.cjs.production.min.js
var redux_toolkit_cjs_production_min = __webpack_require__(91388);
// EXTERNAL MODULE: ./src/redux/features/services/requests.ts
var requests = __webpack_require__(29440);
;// CONCATENATED MODULE: ./src/data/services_name.ts
const services_name = {
    tg: "Telegram",
    ig: "Instagram+Threads",
    wa: "Whatsapp",
    fb: "Facebook",
    go: "Google,youtube,Gmail",
    ds: "Discord",
    oi: "Tinder",
    tw: "Twitter",
    am: "Amazon",
    mm: "Microsoft",
    yw: "Grindr",
    hw: "Alipay/Alibaba/1688",
    me: "Line messenger",
    ot: "Any other <small>call forwarding</small>",
    nv: "Naver",
    lf: "TikTok/Douyin",
    dr: "OpenAI",
    mt: "Steam",
    vk: "vk.com",
    dl: "Lazada",
    vs: "WinzoGame",
    wb: "WeChat",
    vi: "Viber",
    of: "urent/jet/RuSharing",
    tk: "МВидео",
    ts: "PayPal",
    bw: "Signal",
    da: "MTS CashBack",
    ka: "Shopee",
    ub: "Uber",
    ma: "Mail.ru",
    ju: "Indomaret",
    ki: "99app",
    ya: "Yandex <small>call forwarding</small>",
    tn: "LinkedIN",
    uu: "Wildberries",
    fw: "99acres",
    dh: "eBay",
    kt: "KakaoTalk",
    nz: "Foodpanda",
    mj: "Zalo",
    sg: "OZON",
    be: "СберМегаМаркет",
    yl: "Yalla",
    ok: "ok.ru",
    mb: "Yahoo",
    jg: "Grab",
    ew: "Nike",
    ly: "Olacabs",
    abl: "gpnbonus",
    sn: "OLX",
    xj: "СберМаркет",
    xm: "Лэтуаль",
    qf: "RedBook",
    ml: "ApostaGanha",
    av: "avito <small>call forwarding</small>",
    pf: "pof.com",
    wx: "Apple",
    pd: "IFood",
    xh: "OVO",
    fr: "Dana",
    kc: "Vinted",
    kf: "Weibo",
    bc: "GCash",
    df: "Happn",
    pc: "Casino/bet/gambling",
    xd: "Tokopedia",
    pm: "AOL",
    ft: "Букмекерские",
    ll: "888casino",
    cy: "РСА",
    ni: "Gojek",
    mo: "Bumble",
    cq: "Mercado",
    fu: "Snapchat",
    za: "JDcom",
    tx: "Bolt",
    gf: "GoogleVoice",
    uk: "Airbnb",
    wh: "TanTan",
    vz: "Hinge",
    gx: "Hepsiburadacom",
    mv: "Fruitz",
    xk: "DiDi",
    ev: "Picpay ",
    fd: "Mamba",
    bz: "Blizzard",
    ns: "Oldubil",
    nf: "Netflix",
    ac: "DoorDash",
    do: "Leboncoin",
    gj: "Carousell",
    wd: "CasinoPlus",
    zu: "BigC",
    vm: "OkCupid",
    zk: "Deliveroo",
    yr: "Miravia",
    jr: "Самокат",
    tu: "Lyft",
    ov: "Beget",
    zh: "Zoho",
    dp: "ProtonMail",
    im: "Imo",
    qq: "Tencent QQ",
    uf: "Eneba",
    vg: "ShellBox",
    no: "Virgo",
    nt: "Sravni",
    ie: "bet365",
    cp: "Uklon",
    rr: "Wolt",
    fo: "MobiKwik",
    cb: "Bazos",
    rl: "inDriver",
    gk: "AptekaRU",
    ae: "myGLO",
    lx: "DewuPoison",
    ib: "Immowelt",
    xy: "Depop",
    wc: "Craigslist",
    qv: "Badoo",
    mg: "Magnit",
    et: "Clubhouse",
    ls: "Careem",
    pu: "Justdating",
    zs: "Bilibili",
    fk: "BLIBLI",
    bv: "Metro",
    jq: "Paysafecard",
    aaa: "Nubank",
    jl: "Hopi",
    em: "Z\xe9Delivery",
    yk: "СпортМастер",
    bd: "X5ID",
    dt: "Delivery Club",
    ep: "Temu",
    gr: "Astropay",
    qz: "Faceit",
    hu: "Ukrnet",
    vr: "MotorkuX",
    kl: "kolesa.kz",
    nc: "Payoneer",
    re: "Coinbase",
    gp: "Ticketmaster",
    ff: "AVON",
    bo: "Wise",
    xq: "MPL",
    my: "CAIXA",
    mi: "Zupee",
    mx: "SoulApp",
    jx: "Swiggy",
    ms: "NovaPoshta",
    vp: "Kwai",
    vy: "Meta",
    gq: "Freelancer",
    co: "Rediffmail",
    ah: "EscapeFromTarkov",
    rn: "neftm",
    ke: "Эльдорадо",
    zb: "FreeNow",
    vd: "Betfair",
    yu: "Xiaomi",
    wv: "AIS",
    ta: "Wink",
    ix: "Celcoin",
    rd: "Lenta",
    sh: "Vkusvill",
    ng: "FunPay",
    dj: "LUKOIL-AZS",
    rt: "hily",
    bm: "MarketGuru",
    ua: "BlaBlaCar",
    zo: "Kaggle",
    rk: "Fotka",
    rc: "Skype",
    sy: "Brahma",
    xt: "Flipkart",
    yj: "eWallet",
    fj: "Potato Chat",
    ex: "Linode",
    hb: "Twitch",
    oo: "LigaPro",
    ct: "КухняНаРайоне",
    aav: "Alchemy ",
    li: "Baidu",
    bh: "Uteka",
    aay: "JioMart",
    hy: "Ininal",
    je: "Nanovest",
    xr: "Tango",
    rq: "AptekiPlus",
    xu: "RecargaPay",
    ys: "ZCity",
    kv: "Rush",
    fz: "KFC",
    abc: "TapTap",
    tl: "Truecaller",
    abk: "GMX",
    aaq: "Netease",
    ko: "AdaKami",
    ht: "Bitso",
    uz: "OffGamers",
    aq: "Glovo",
    qy: "Zhihu",
    jc: "IVI",
    lj: "Santander",
    bl: "BIGO LIVE",
    kx: "Vivo",
    kk: "Idealista",
    yy: "Venmo",
    bn: "Alfagift",
    ps: "Zdorov",
    wg: "Skout",
    uy: "Meliuz",
    ud: "Disney Hotstar",
    yh: "hh",
    ck: "BeReal",
    cm: "Prom",
    ij: "Revolut",
    vc: "Banqi",
    ad: "Iti",
    rj: "Детский мир",
    ze: "Shpock",
    hx: "AliExpress",
    sm: "YoWin",
    nl: "Myntra",
    dn: "Paxful",
    ym: "youla.ru <small>call forwarding</small>",
    yd: "米画师Mihuashi",
    cj: "Dotz",
    xs: "GroupMe",
    zm: "OfferUp",
    kq: "FotoCasa",
    pz: "Lidl",
    ue: "Onet",
    fh: "Lalamove",
    zd: "Zilch",
    oj: "LoveRu",
    zr: "Papara",
    sl: "СберАптека",
    cn: "Fiverr",
    il: "IQOS",
    wr: "Walmart",
    ul: "Getir",
    bb: "LazyPay",
    mc: "Michat",
    sb: "Lamoda",
    ch: "Pocket52",
    qo: "Moneylion",
    dc: "YikYak",
    sv: "Dostavista",
    yn: "Allegro",
    iq: "icq",
    zl: "Airtel",
    jv: "Consultant",
    sd: "dodopizza",
    ye: "ZaleyCash",
    ak: "Douyu",
    og: "Okko",
    zz: "DENT",
    mp: "Winmasters",
    yp: "Payzapp",
    cr: "TenChat",
    it: "CashApp",
    oz: "Poshmark",
    aau: "RockeTreach",
    fg: "IndianOil",
    qr: "MEGA",
    gg: "PagSmile",
    kh: "Bukalapak",
    lg: "MediBuddy",
    rh: "Ace2Three",
    gu: "Fora",
    jy: "Sorare",
    wp: "163СOM",
    jo: "SticPay",
    qd: "Taobao",
    cw: "PaddyPower",
    ja: "Weverse",
    ru: "HOP",
    kj: "YAPPY",
    ti: "cryptocom",
    fx: "PGbonus <small>call forwarding</small>",
    nw: "Ximalaya",
    ee: "Twilio",
    kb: "kufarby",
    aba: "Rappi",
    ay: "Ruten",
    sa: "AGIBANK",
    ve: "Dream11",
    aa: "Probo",
    qn: "Blued ",
    jd: "GiraBank",
    hc: "MOMO",
    ip: "Burger King",
    kz: "NimoTV",
    we: "DrugVokrug",
    aj: "OneAset",
    ge: "Paytm",
    lq: "Potato",
    zy: "Nttgame",
    hq: "Magicbricks",
    lc: "Subito",
    nq: "Trip",
    ai: "CELEBe",
    an: "Adidas",
    ao: "UU163",
    ar: "Wondermart",
    at: "Perfluence",
    aw: "Taikang",
    ax: "CrefisaMais",
    ba: "Expressmoney",
    aab: "BharatPe",
    bf: "Keybase ",
    aag: "Pockit",
    bi: "勇仕网络Ys4fun",
    bk: "G2G",
    bq: "Adani",
    br: "Вкусно и Точка",
    bs: "TradeUP",
    aap: "Tiptapp",
    bt: "Alfa",
    aas: "XXGame",
    bu: "MonobankIndia",
    aar: "Bearwww",
    aat: "TamTam",
    bx: "Dosi",
    aaw: "Aya Bank",
    aax: "Boyaa",
    aaz: "Ozan",
    ca: "SuperS",
    cc: "Quipp",
    abb: "Coca-Cola",
    ce: "mosru",
    cf: "irancell",
    cg: "Gemgala",
    ci: "redBus",
    cl: "UWIN",
    abi: "BytePlus",
    abn: "Namars",
    cu: "炙热星河",
    cv: "WashXpress",
    cx: "Icrypex",
    cz: "Getmega",
    dd: "CloudChat",
    de: "Karusel",
    dg: "Mercari",
    di: "Loanflix",
    dq: "IceCasino",
    du: "AUBANK",
    dv: "NoBroker",
    dz: "Dominos Pizza",
    eb: "Voltz",
    ec: "RummyCulture",
    ef: "Nextdoor",
    ej: "MrQ",
    el: "Bisu",
    en: "Hermes",
    eq: "Qoo10",
    es: "iQIYI",
    eu: "LiveScore",
    ez: "GoerliFaucet",
    fa: "XadrezFeliz",
    fc: "PharmEasy",
    fe: "CliQQ",
    fi: "Dundle",
    fl: "RummyLoot",
    fs: " Şikayet var",
    fv: "Vidio",
    fy: "Mylove",
    ga: "Roposo",
    gb: "YouStar",
    gd: "Surveytime",
    gh: "GyFTR",
    gi: "Hotline",
    gm: "Mocospace",
    gs: "SamsungShop",
    gt: "Gett",
    gw: "CallApp",
    gz: "LYKA",
    ha: "My11Circle",
    he: "Mewt",
    hg: "Switips",
    hh: "Uplay",
    hi: "JungleeRummy",
    hk: "4Fun",
    hl: "Band",
    ho: "Cathay",
    hp: "Meesho",
    hr: "JKF",
    ih: "TeenPattiStarpro",
    ii: "CashKaro",
    ik: "GuruBets",
    io: "ЗдравСити",
    ir: "Chispa",
    iu: "Bykea",
    iw: "MyLavash",
    iy: "FoodHub",
    jf: "Likee",
    jh: "PingPong",
    jj: "Aitu",
    jm: "mzadqatar",
    jp: "Rbt",
    js: "GolosZa",
    jz: "Kaya",
    kd: "Author24",
    kg: "FreeChargeApp",
    km: "Rozetka",
    kp: "HQ Trivia",
    ks: "Hirect",
    ku: "RoyalWin",
    kw: "Foody",
    ky: "SpatenOktoberfest",
    ld: "Cashmine",
    le: "E bike Gewinnspiel",
    lh: "24betting",
    lk: "PurePlatfrom",
    lm: "FarPost",
    ln: "Grofers",
    lo: "OPPO",
    lp: "Algida",
    lt: "BitClout",
    lu: "Crickpe",
    lv: "Megogo",
    lw: "MrGreen",
    lz: "Things",
    mk: "LongHu",
    mn: "RRSA",
    mq: "GMNG",
    mw: "Transfergo",
    mz: "Zolushka",
    ne: "Coindcx",
    nj: "FreshKarta",
    nk: "Gittigidiyor",
    nm: "Thisshop",
    nn: "Giftcloud",
    np: "Siply",
    nr: "Tosla",
    oc: "DealShare",
    od: "FWDMAX",
    oe: "Codashop",
    oh: "MapleSEA ",
    ol: "KazanExpress",
    om: "Corona",
    oq: "Vlife",
    os: "Dhani",
    ow: "RegRu",
    ox: "Damejidlo",
    oy: "CashFly",
    pa: "Gamekit",
    pb: "SkyTV",
    pj: "Podeli",
    pn: "CoffeeLike",
    po: "premium.one",
    pp: "Huya",
    pr: "Trendyol",
    pt: "Bitaqaty",
    pv: "Koshelek",
    pw: "SellMonitor",
    py: "Monese",
    qa: "MyFishka",
    qe: "GG",
    qg: "MoneyPay",
    qh: "Oriflame",
    qi: "32red",
    qk: "Bit",
    ql: "CMTcuzdan",
    qp: "Максавит",
    qs: "МирЗнакомств",
    qt: "MoneyСontrol",
    qu: "Agroinform",
    qx: "WorldRemit",
    ra: "KeyPay",
    rb: "Tick",
    rf: "Akudo",
    rg: "Porbet",
    rm: "Faberlic",
    ro: "PingCode",
    rs: "Lotus",
    rv: "Kotak811",
    ry: "McDonalds",
    rz: "EasyPay",
    sc: "Voggt",
    sf: "SneakersnStuff",
    sk: "Skroutz",
    so: "RummyWealth",
    sr: "Starbucks",
    ss: "hezzl",
    st: "Auchan",
    su: "LOCO",
    sz: "Pivko24",
    tf: "Noon",
    th: "WestStein",
    tp: "IndiaGold",
    tq: "Swvl",
    ty: "Окей",
    tz: "Лейка",
    uh: "Yubo",
    ui: "RuTube",
    uj: "СhampionСasino",
    um: "Belwest",
    un: "humblebundle",
    uo: "CafeBazaar",
    uq: "TopDetal",
    us: "IRCTC",
    ut: "Энергобум",
    uv: "BinBin",
    uw: "Kirana",
    ux: "Домовой",
    va: "SportGully",
    vb: "Кораблик",
    vh: "Штолле",
    vj: "Stormgain",
    vl: "Ортека",
    vn: "Yaay",
    vq: "LadyMaria",
    wn: "GameArena",
    wo: "Parkplus",
    ws: "Indodax",
    wt: "IZI",
    wu: "PrivetMir",
    ww: "BIP",
    wy: "Yami",
    wz: "FoxFord",
    xa: "УлыбкаРадуги",
    xb: "RummyOla",
    xc: "SynotTip",
    xe: "GalaxyChat",
    xf: "LightChat",
    xg: "FortunaSK",
    xi: "InFund",
    xl: "Wmaraci",
    xn: "Familia",
    xo: "Notifire",
    xp: "MonetaRu",
    xv: "Wish",
    xw: "Taki",
    xx: "Joyride",
    xz: "paycell",
    yf: "Citymobil",
    yg: "CourseHero",
    yi: "Yemeksepeti",
    yo: "Amasia",
    yv: "IPLwin",
    yx: "JTExpress",
    yz: "Около",
    zi: "LoveLocal",
    zj: "ROBINHOOD",
    zn: "Biedronka",
    zp: "Pinduoduo",
    zq: "IndiaPlays",
    zt: "Budweiser",
    zv: "Digikala",
    zx: "CommunityGaming"
};
/* harmony default export */ const data_services_name = (services_name);

;// CONCATENATED MODULE: ./src/redux/features/services/servicesSlice.ts



const initialState = {
    data: {},
    countries: {},
    services: {},
    selectedService: {},
    visibleValue: 20,
    loading: false,
    fetched: false,
    countries_loading: false,
    countries_fetched: false,
    error: ""
};
const serviceSlice = (0,redux_toolkit_cjs_production_min.createSlice)({
    name: "services",
    initialState,
    reducers: {
        setSelectedService (state, action) {
            state.selectedService = action.payload;
        },
        removeSelectedService (state) {
            state.selectedService = {};
        },
        moreVisible (state, action) {
            state.visibleValue = state.visibleValue + action.payload;
        },
        resetVisible (state) {
            state.visibleValue = 20;
        }
    },
    extraReducers: (builder)=>{
        builder.addCase(requests/* fetchServices */.Q.pending, (state)=>{
            state.loading = true;
        });
        builder.addCase(requests/* fetchServices */.Q.fulfilled, (state, action)=>{
            state.loading = false;
            state.data = action.payload?.data || {};
            state.services = Object.keys(action.payload?.data || {}).reduce((acc, val)=>{
                acc[val] = {
                    shortName: val,
                    name: data_services_name[val],
                    logo: `https://smsactivate.s3.eu-central-1.amazonaws.com/assets/ico/${val}0.webp`
                };
                return acc;
            }, {});
            state.error = "";
            state.fetched = true;
        });
        builder.addCase(requests/* fetchServices */.Q.rejected, (state, action)=>{
            state.loading = false;
            state.data = {};
            state.services = {};
            state.fetched = true;
            state.error = action.error.message;
        });
        builder.addCase(requests/* fetchCountries */.t.pending, (state)=>{
            state.countries_loading = true;
        });
        builder.addCase(requests/* fetchCountries */.t.fulfilled, (state, action)=>{
            state.countries = action?.payload?.data;
            state.error = "";
            state.countries_loading = false;
            state.countries_fetched = true;
        });
        builder.addCase(requests/* fetchCountries */.t.rejected, (state, action)=>{
            state.countries = {};
            state.countries_loading = false;
            state.countries_fetched = true;
            state.error = action.error.message;
        });
    }
});
const serviceActions = serviceSlice.actions;
/* harmony default export */ const servicesSlice = (serviceSlice);


/***/ }),

/***/ 10:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   M7: () => (/* binding */ useReduxSelector),
/* harmony export */   Ns: () => (/* binding */ useReduxDispatch),
/* harmony export */   ZP: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(91388);
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(8250);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_redux__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _features_services_servicesSlice__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(29719);
/* harmony import */ var _features_activations_activationsSlice__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(3497);




const redux_store = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_3__.configureStore)({
    reducer: {
        services: _features_services_servicesSlice__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z.reducer,
        activations: _features_activations_activationsSlice__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z.reducer
    },
    devTools: "production" === "development"
});
const useReduxDispatch = ()=>(0,react_redux__WEBPACK_IMPORTED_MODULE_0__.useDispatch)();
const useReduxSelector = react_redux__WEBPACK_IMPORTED_MODULE_0__.useSelector;
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (redux_store);


/***/ }),

/***/ 86334:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ RootLayout),
  metadata: () => (/* binding */ metadata)
});

// EXTERNAL MODULE: external "next/dist/compiled/react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(56786);
// EXTERNAL MODULE: ./node_modules/next/font/google/target.css?{"path":"src\\app\\layout.tsx","import":"Roboto","arguments":[{"subsets":["latin"],"weight":["100","300","400","500","700"]}],"variableName":"roboto"}
var target_path_src_app_layout_tsx_import_Roboto_arguments_subsets_latin_weight_100_300_400_500_700_variableName_roboto_ = __webpack_require__(60018);
var target_path_src_app_layout_tsx_import_Roboto_arguments_subsets_latin_weight_100_300_400_500_700_variableName_roboto_default = /*#__PURE__*/__webpack_require__.n(target_path_src_app_layout_tsx_import_Roboto_arguments_subsets_latin_weight_100_300_400_500_700_variableName_roboto_);
// EXTERNAL MODULE: ./src/app/globals.css
var globals = __webpack_require__(5023);
// EXTERNAL MODULE: ./node_modules/react-responsive-pagination/themes/classic.css
var classic = __webpack_require__(93952);
// EXTERNAL MODULE: ./node_modules/next/dist/build/webpack/loaders/next-flight-loader/module-proxy.js
var module_proxy = __webpack_require__(61363);
;// CONCATENATED MODULE: ./src/app/Providers.tsx

const proxy = (0,module_proxy.createProxy)(String.raw`S:\Web Applications\NextJS\YenSMS\src\app\Providers.tsx`)

// Accessing the __esModule property and exporting $$typeof are required here.
// The __esModule getter forces the proxy target to create the default export
// and the $$typeof value is for rendering logic to determine if the module
// is a client boundary.
const { __esModule, $$typeof } = proxy;
const __default__ = proxy.default;


/* harmony default export */ const Providers = (__default__);
;// CONCATENATED MODULE: ./src/components/client/header/ClientHeader.tsx

const ClientHeader_proxy = (0,module_proxy.createProxy)(String.raw`S:\Web Applications\NextJS\YenSMS\src\components\client\header\ClientHeader.tsx`)

// Accessing the __esModule property and exporting $$typeof are required here.
// The __esModule getter forces the proxy target to create the default export
// and the $$typeof value is for rendering logic to determine if the module
// is a client boundary.
const { __esModule: ClientHeader_esModule, $$typeof: ClientHeader_$$typeof } = ClientHeader_proxy;
const ClientHeader_default_ = ClientHeader_proxy.default;


/* harmony default export */ const ClientHeader = (ClientHeader_default_);
;// CONCATENATED MODULE: ./src/components/client/footer/ClientFooter.tsx

const ClientFooter_proxy = (0,module_proxy.createProxy)(String.raw`S:\Web Applications\NextJS\YenSMS\src\components\client\footer\ClientFooter.tsx`)

// Accessing the __esModule property and exporting $$typeof are required here.
// The __esModule getter forces the proxy target to create the default export
// and the $$typeof value is for rendering logic to determine if the module
// is a client boundary.
const { __esModule: ClientFooter_esModule, $$typeof: ClientFooter_$$typeof } = ClientFooter_proxy;
const ClientFooter_default_ = ClientFooter_proxy.default;


/* harmony default export */ const ClientFooter = (ClientFooter_default_);
;// CONCATENATED MODULE: ./src/app/layout.tsx







const metadata = {
    title: "YEN:SMS Verification",
    description: "Text Verification Web Application"
};
function RootLayout({ children }) {
    return /*#__PURE__*/ jsx_runtime_.jsx("html", {
        lang: "en",
        children: /*#__PURE__*/ jsx_runtime_.jsx("body", {
            className: (target_path_src_app_layout_tsx_import_Roboto_arguments_subsets_latin_weight_100_300_400_500_700_variableName_roboto_default()).className + " text-gray-900 dark:text-gray-100 bg-gray-50 dark:bg-gray-900",
            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Providers, {
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx(ClientHeader, {}),
                    children,
                    /*#__PURE__*/ jsx_runtime_.jsx(ClientFooter, {})
                ]
            })
        })
    });
}


/***/ }),

/***/ 88924:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ Loading)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(56786);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(62947);


function Loading() {
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        className: "flex items-center justify-center h-screen",
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
            role: "status",
            children: [
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("svg", {
                    "aria-hidden": "true",
                    className: "w-8 h-8 mr-2 text-gray-200 animate-spin dark:text-gray-600 fill-blue-600",
                    viewBox: "0 0 100 101",
                    fill: "none",
                    xmlns: "http://www.w3.org/2000/svg",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                            d: "M100 50.5908C100 78.2051 77.6142 100.591 50 100.591C22.3858 100.591 0 78.2051 0 50.5908C0 22.9766 22.3858 0.59082 50 0.59082C77.6142 0.59082 100 22.9766 100 50.5908ZM9.08144 50.5908C9.08144 73.1895 27.4013 91.5094 50 91.5094C72.5987 91.5094 90.9186 73.1895 90.9186 50.5908C90.9186 27.9921 72.5987 9.67226 50 9.67226C27.4013 9.67226 9.08144 27.9921 9.08144 50.5908Z",
                            fill: "currentColor"
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                            d: "M93.9676 39.0409C96.393 38.4038 97.8624 35.9116 97.0079 33.5539C95.2932 28.8227 92.871 24.3692 89.8167 20.348C85.8452 15.1192 80.8826 10.7238 75.2124 7.41289C69.5422 4.10194 63.2754 1.94025 56.7698 1.05124C51.7666 0.367541 46.6976 0.446843 41.7345 1.27873C39.2613 1.69328 37.813 4.19778 38.4501 6.62326C39.0873 9.04874 41.5694 10.4717 44.0505 10.1071C47.8511 9.54855 51.7191 9.52689 55.5402 10.0491C60.8642 10.7766 65.9928 12.5457 70.6331 15.2552C75.2735 17.9648 79.3347 21.5619 82.5849 25.841C84.9175 28.9121 86.7997 32.2913 88.1811 35.8758C89.083 38.2158 91.5421 39.6781 93.9676 39.0409Z",
                            fill: "currentFill"
                        })
                    ]
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                    className: "sr-only",
                    children: "Loading..."
                })
            ]
        })
    });
}


/***/ }),

/***/ 73881:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var next_dist_lib_metadata_get_metadata_route__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(80085);
/* harmony import */ var next_dist_lib_metadata_get_metadata_route__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_dist_lib_metadata_get_metadata_route__WEBPACK_IMPORTED_MODULE_0__);
  

  /* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ((props) => {
    const imageData = {"type":"image/x-icon","sizes":"16x16"}
    const imageUrl = (0,next_dist_lib_metadata_get_metadata_route__WEBPACK_IMPORTED_MODULE_0__.fillMetadataSegment)(".", props.params, "favicon.ico")

    return [{
      ...imageData,
      url: imageUrl + "",
    }]
  });

/***/ }),

/***/ 5023:
/***/ (() => {



/***/ })

};
;