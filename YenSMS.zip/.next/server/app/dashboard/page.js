(() => {
var exports = {};
exports.id = 7702;
exports.ids = [7702];
exports.modules = {

/***/ 18038:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react");

/***/ }),

/***/ 98704:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react-dom/server-rendering-stub");

/***/ }),

/***/ 97897:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react-server-dom-webpack/client");

/***/ }),

/***/ 56786:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react/jsx-runtime");

/***/ }),

/***/ 5868:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/app-render/app-render");

/***/ }),

/***/ 41844:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/app-render/get-segment-param");

/***/ }),

/***/ 96624:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/future/helpers/interception-routes");

/***/ }),

/***/ 75281:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/future/route-modules/route-module");

/***/ }),

/***/ 57085:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/app-router-context");

/***/ }),

/***/ 1830:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/get-img-props");

/***/ }),

/***/ 20199:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/hash");

/***/ }),

/***/ 66864:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/head");

/***/ }),

/***/ 39569:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/hooks-client-context");

/***/ }),

/***/ 52210:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config");

/***/ }),

/***/ 35359:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config-context");

/***/ }),

/***/ 17160:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router-context");

/***/ }),

/***/ 30893:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/add-path-prefix");

/***/ }),

/***/ 12336:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/format-url");

/***/ }),

/***/ 17887:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/handle-smooth-scroll");

/***/ }),

/***/ 98735:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-bot");

/***/ }),

/***/ 60120:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-local-url");

/***/ }),

/***/ 68231:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-path");

/***/ }),

/***/ 54614:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/path-has-prefix");

/***/ }),

/***/ 53750:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash");

/***/ }),

/***/ 70982:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/resolve-href");

/***/ }),

/***/ 79618:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/server-inserted-html");

/***/ }),

/***/ 78423:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils");

/***/ }),

/***/ 98658:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils/warn-once");

/***/ }),

/***/ 39491:
/***/ ((module) => {

"use strict";
module.exports = require("assert");

/***/ }),

/***/ 82361:
/***/ ((module) => {

"use strict";
module.exports = require("events");

/***/ }),

/***/ 57147:
/***/ ((module) => {

"use strict";
module.exports = require("fs");

/***/ }),

/***/ 13685:
/***/ ((module) => {

"use strict";
module.exports = require("http");

/***/ }),

/***/ 95687:
/***/ ((module) => {

"use strict";
module.exports = require("https");

/***/ }),

/***/ 22037:
/***/ ((module) => {

"use strict";
module.exports = require("os");

/***/ }),

/***/ 71017:
/***/ ((module) => {

"use strict";
module.exports = require("path");

/***/ }),

/***/ 12781:
/***/ ((module) => {

"use strict";
module.exports = require("stream");

/***/ }),

/***/ 76224:
/***/ ((module) => {

"use strict";
module.exports = require("tty");

/***/ }),

/***/ 57310:
/***/ ((module) => {

"use strict";
module.exports = require("url");

/***/ }),

/***/ 73837:
/***/ ((module) => {

"use strict";
module.exports = require("util");

/***/ }),

/***/ 59796:
/***/ ((module) => {

"use strict";
module.exports = require("zlib");

/***/ }),

/***/ 41362:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   GlobalError: () => (/* reexport default from dynamic */ next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_2___default.a),
/* harmony export */   __next_app__: () => (/* binding */ __next_app__),
/* harmony export */   originalPathname: () => (/* binding */ originalPathname),
/* harmony export */   pages: () => (/* binding */ pages),
/* harmony export */   routeModule: () => (/* binding */ routeModule),
/* harmony export */   tree: () => (/* binding */ tree)
/* harmony export */ });
/* harmony import */ var next_dist_server_future_route_modules_app_page_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(7262);
/* harmony import */ var next_dist_server_future_route_modules_app_page_module__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_dist_server_future_route_modules_app_page_module__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_dist_server_future_route_kind__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(19513);
/* harmony import */ var next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(31823);
/* harmony import */ var next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(12502);
/* harmony import */ var next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_3__);
/* harmony reexport (unknown) */ var __WEBPACK_REEXPORT_OBJECT__ = {};
/* harmony reexport (unknown) */ for(const __WEBPACK_IMPORT_KEY__ in next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_3__) if(["default","tree","pages","GlobalError","originalPathname","__next_app__","routeModule"].indexOf(__WEBPACK_IMPORT_KEY__) < 0) __WEBPACK_REEXPORT_OBJECT__[__WEBPACK_IMPORT_KEY__] = () => next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_3__[__WEBPACK_IMPORT_KEY__]
/* harmony reexport (unknown) */ __webpack_require__.d(__webpack_exports__, __WEBPACK_REEXPORT_OBJECT__);
// @ts-ignore this need to be imported from next/dist to be external


const AppPageRouteModule = next_dist_server_future_route_modules_app_page_module__WEBPACK_IMPORTED_MODULE_0__.AppPageRouteModule;
// We inject the tree and pages here so that we can use them in the route
// module.
const tree = {
        children: [
        '',
        {
        children: [
        'dashboard',
        {
        children: ['__PAGE__', {}, {
          page: [() => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 64644)), "S:\\Web Applications\\NextJS\\YenSMS\\src\\app\\dashboard\\page.tsx"],
          
        }]
      },
        {
          
          metadata: {
    icon: [(async (props) => (await Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 73881))).default(props))],
    apple: [],
    openGraph: [],
    twitter: [],
    manifest: undefined
  }
        }
      ]
      },
        {
          'layout': [() => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 86334)), "S:\\Web Applications\\NextJS\\YenSMS\\src\\app\\layout.tsx"],
'loading': [() => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 88924)), "S:\\Web Applications\\NextJS\\YenSMS\\src\\app\\loading.tsx"],
          metadata: {
    icon: [(async (props) => (await Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 73881))).default(props))],
    apple: [],
    openGraph: [],
    twitter: [],
    manifest: undefined
  }
        }
      ]
      }.children;
const pages = ["S:\\Web Applications\\NextJS\\YenSMS\\src\\app\\dashboard\\page.tsx"];

// @ts-expect-error - replaced by webpack/turbopack loader

const __next_app_require__ = __webpack_require__
const __next_app_load_chunk__ = () => Promise.resolve()
const originalPathname = "/dashboard/page";
const __next_app__ = {
    require: __next_app_require__,
    loadChunk: __next_app_load_chunk__
};

// Create and export the route module that will be consumed.
const routeModule = new AppPageRouteModule({
    definition: {
        kind: next_dist_server_future_route_kind__WEBPACK_IMPORTED_MODULE_1__.RouteKind.APP_PAGE,
        page: "/dashboard/page",
        pathname: "/dashboard",
        // The following aren't used in production.
        bundlePath: "",
        filename: "",
        appPaths: []
    },
    userland: {
        loaderTree: tree
    }
});

//# sourceMappingURL=app-page.js.map

/***/ }),

/***/ 83745:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 46598))

/***/ }),

/***/ 46598:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ Dashboard)
});

// EXTERNAL MODULE: external "next/dist/compiled/react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(56786);
// EXTERNAL MODULE: external "next/dist/compiled/react"
var react_ = __webpack_require__(18038);
var react_default = /*#__PURE__*/__webpack_require__.n(react_);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/Box/index.js
var Box = __webpack_require__(43872);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/ListItem/index.js
var ListItem = __webpack_require__(43610);
var ListItem_default = /*#__PURE__*/__webpack_require__.n(ListItem);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/ListItemButton/index.js
var ListItemButton = __webpack_require__(19868);
var ListItemButton_default = /*#__PURE__*/__webpack_require__.n(ListItemButton);
// EXTERNAL MODULE: ./src/redux/redux_store.ts
var redux_store = __webpack_require__(10);
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(52451);
var image_default = /*#__PURE__*/__webpack_require__.n(next_image);
// EXTERNAL MODULE: ./src/common/MaterialUi/Forms/MuiTextField.tsx
var MuiTextField = __webpack_require__(94389);
// EXTERNAL MODULE: ./src/redux/features/services/requests.ts
var requests = __webpack_require__(29440);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/Skeleton/index.js
var Skeleton = __webpack_require__(10413);
var Skeleton_default = /*#__PURE__*/__webpack_require__.n(Skeleton);
// EXTERNAL MODULE: ./node_modules/uid/dist/index.mjs
var dist = __webpack_require__(34521);
;// CONCATENATED MODULE: ./src/common/MaterialUi/Skeleton/ListSkeleton.tsx




function ListSkeleton({ count, height }) {
    return /*#__PURE__*/ jsx_runtime_.jsx(jsx_runtime_.Fragment, {
        children: new Array(count).fill("").map(()=>/*#__PURE__*/ jsx_runtime_.jsx((Skeleton_default()), {
                height: height,
                width: "100%"
            }, (0,dist/* uid */.h)()))
    });
}

;// CONCATENATED MODULE: ./src/hooks/state/useBoolean.ts

function useBoolean(_default) {
    const [isTrue, set] = (0,react_.useState)(_default || false);
    const [loading, setLoading] = (0,react_.useState)(false);
    return {
        true: isTrue,
        set,
        setTrue: ()=>set(true),
        setFalse: ()=>set(false),
        toggle: ()=>set((p)=>!p),
        toggleTwice: (time)=>{
            set(true);
            setTimeout(()=>{
                set(false);
            }, time || 100);
        },
        changeChecked: (e)=>set(e.target.checked),
        loading,
        setLoading
    };
}

;// CONCATENATED MODULE: ./src/hooks/state/useString.ts


const useString = (defaultValue)=>{
    const [value, setValue] = (0,react_.useState)(defaultValue || "");
    const loading = useBoolean();
    return {
        value,
        reset: ()=>setValue(""),
        change: (e)=>setValue(e.target.value),
        setCustom: (val)=>setValue(val || ""),
        loading
    };
};
/* harmony default export */ const state_useString = (useString);

;// CONCATENATED MODULE: ./src/lib/dynamic_filter.ts
function dynamic_filter(arr, keys, filterText) {
    return arr.filter((item)=>{
        if (!keys || !filterText) return arr;
        for (const key of keys){
            const value = item[key];
            if (value && value?.trim()?.toLowerCase()?.includes(filterText?.trim()?.toLowerCase())) {
                return true;
            }
        }
        return false;
    });
}

// EXTERNAL MODULE: ./src/redux/features/services/servicesSlice.ts + 1 modules
var servicesSlice = __webpack_require__(29719);
// EXTERNAL MODULE: ./src/common/FIcon.tsx
var common_FIcon = __webpack_require__(42635);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/index.js
var node = __webpack_require__(17421);
// EXTERNAL MODULE: ./src/lib/toast.ts
var toast = __webpack_require__(40696);
// EXTERNAL MODULE: ./node_modules/react-toastify/dist/react-toastify.esm.mjs
var react_toastify_esm = __webpack_require__(34751);
;// CONCATENATED MODULE: ./src/lib/toast_async.ts

async function toast_async(func, messages) {
    const response = await react_toastify_esm/* toast */.Am.promise(func, {
        pending: messages?.start || "Please wait a moment...",
        success: {
            render ({ data }) {
                return messages?.success || data?.message || data?.data?.message;
            }
        },
        error: {
            render ({ data }) {
                return messages?.error || data?.message || data?.data?.message;
            }
        }
    });
    return response;
}

// EXTERNAL MODULE: ./src/redux/features/activations/activationsSlice.ts
var activationsSlice = __webpack_require__(3497);
// EXTERNAL MODULE: ./node_modules/axios/lib/axios.js + 46 modules
var axios = __webpack_require__(93258);
;// CONCATENATED MODULE: ./src/app/dashboard/hooks.ts







function useGetActivationsCode(fetchingCode) {
    const dispatch = (0,redux_store/* useReduxDispatch */.Ns)();
    return async ()=>{
        fetchingCode?.setTrue();
        function updateData(data) {
            dispatch(activationsSlice/* activationActions */.e.updateActivations(data.activeActivations));
        }
        function receivedAll(data) {
            return data.activeActivations?.every((a)=>a.smsCode);
        }
        function cancelStatus() {
            dispatch(activationsSlice/* activationActions */.e.cancelActivationsStatus());
        }
        let fetch_code = setInterval(async ()=>{
            console.count(new Date().toLocaleTimeString());
            const response = await axios/* default */.Z.get(`/api/sms-active/getActiveActivations`);
            const data = response?.data?.data;
            if (data?.error || data?.status === "error") {
                clearInterval(fetch_code);
                if (receivedAll(data)) {
                    updateData(data);
                } else {
                    cancelStatus();
                }
            } else updateData(data);
        }, 30000);
        const response = await axios/* default */.Z.get(`/api/sms-active/getActiveActivations`);
        const data = response?.data?.data;
        if (data?.error || data?.status === "error") {
            clearInterval(fetch_code);
            if (receivedAll(data)) {
                updateData(data);
            } else {
                cancelStatus();
            }
        } else updateData(data);
    };
}
function useOrderNumber(serviceCode, serviceCountryCode, loading) {
    const dispatch = (0,redux_store/* useReduxDispatch */.Ns)();
    const getCode = useGetActivationsCode();
    return async ()=>{
        loading && loading.setTrue();
        try {
            const { data } = await toast_async(axios/* default */.Z.get(`/api/sms-active/getNumberV2?service=${serviceCode}&country=${serviceCountryCode}&operator=tmobile`), {
                start: "Order is processing...",
                success: "Processing completed!",
                error: "Failed, Please contact support!"
            });
            if (typeof data?.data === "string") {
                react_toastify_esm/* toast */.Am.dismiss();
                (0,toast/* default */.Z)({
                    message: data?.data,
                    type: "warn"
                });
            } else {
                (0,toast/* default */.Z)({
                    message: "Congrats! You've ordered!",
                    type: "info"
                });
            }
            if (data?.data?.activationId) {
                const { activationId, countryCode, activationTime, activationOperator, phoneNumber, canGetAnotherSms, cost } = data?.data;
                const newActivation = {
                    id: (0,dist/* uid */.h)(),
                    activationId,
                    phoneNumber,
                    time: activationTime,
                    operator: activationOperator,
                    cost,
                    canGetAnotherSms,
                    status: "STATUS_WAIT_CODE",
                    sms_code: [],
                    sms_text: [],
                    countryCode,
                    serviceCode,
                    country_logo: `https://smsactivate.s3.eu-central-1.amazonaws.com/assets/ico/country/${serviceCountryCode}.svg`,
                    service_logo: `https://smsactivate.s3.eu-central-1.amazonaws.com/assets/ico/${serviceCode}0.webp`
                };
                dispatch(activationsSlice/* activationActions */.e.addActivation(newActivation));
                getCode();
            }
        } finally{
            loading && loading.setFalse();
        }
    };
}

// EXTERNAL MODULE: ./node_modules/next-auth/react/index.js
var react = __webpack_require__(74284);
;// CONCATENATED MODULE: ./src/app/dashboard/CountryDetailsByService.tsx










function CountryDetailsByService({ service }) {
    const { data: session } = (0,react.useSession)();
    const loading = useBoolean();
    const { selectedService } = (0,redux_store/* useReduxSelector */.M7)((s)=>s.services);
    const handleOrderNumber = useOrderNumber(selectedService?.shortName, service.country, loading);
    function handleOrderNumberBtn() {
        if (session?.user?.email === "bangladeshisoftware@gmail.com") {
            handleOrderNumber();
        } else {
            (0,toast/* default */.Z)({
                message: "Insufficient Balance!",
                type: "warn"
            });
        }
    }
    return /*#__PURE__*/ jsx_runtime_.jsx("div", {
        children: /*#__PURE__*/ jsx_runtime_.jsx(node.ListItem, {
            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(node.ListItemButton, {
                disabled: loading.true,
                onClick: handleOrderNumberBtn,
                className: "flex items-center justify-between gap-2",
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "flex items-center gap-2",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                src: `https://smsactivate.s3.eu-central-1.amazonaws.com/assets/ico/country/${service?.country}.svg`,
                                width: 40,
                                height: 20,
                                className: "h-8 w-auto",
                                alt: ""
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "flex flex-col items-start gap-0 leading-5",
                                children: [
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("span", {
                                        className: "font-medium",
                                        children: [
                                            " ",
                                            service?.eng,
                                            " "
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("small", {
                                        children: [
                                            service?.count || 0,
                                            " pcs "
                                        ]
                                    })
                                ]
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "w-fit ml-auto flex items-center gap-2",
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "flex flex-col leading-4",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("small", {
                                        children: "Price"
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("small", {
                                        className: "font-semibold",
                                        children: [
                                            service?.price,
                                            ".",
                                            /*#__PURE__*/ jsx_runtime_.jsx(common_FIcon/* default */.Z, {
                                                icon: "ruble"
                                            })
                                        ]
                                    })
                                ]
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx(node.IconButton, {
                                color: "warning",
                                children: /*#__PURE__*/ jsx_runtime_.jsx(common_FIcon/* default */.Z, {
                                    icon: "shopping-cart"
                                })
                            })
                        ]
                    })
                ]
            })
        })
    });
}

;// CONCATENATED MODULE: ./src/common/ShowAndLessButton.tsx



function ShowAndLessButton({ shouldHide, fullLength, showLength, onMore, onLess }) {
    if (shouldHide) return null;
    return showLength >= fullLength ? /*#__PURE__*/ jsx_runtime_.jsx(node.Button, {
        className: "w-full",
        color: "warning",
        onClick: onLess,
        children: "Less more..."
    }) : /*#__PURE__*/ jsx_runtime_.jsx(node.Button, {
        className: "w-full",
        onClick: onMore,
        color: "secondary",
        children: "Show more..."
    });
}

;// CONCATENATED MODULE: ./src/common/WarningText.tsx


function WarningText({ shouldShow, text }) {
    if (!shouldShow) return null;
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("p", {
        className: "text-yellow-700",
        children: [
            " ",
            text || "Not Available!",
            " "
        ]
    });
}

;// CONCATENATED MODULE: ./src/app/dashboard/ManageSelectedService.tsx
















function ManageSelectedService() {
    const dispatch = (0,redux_store/* useReduxDispatch */.Ns)();
    const [serviceCountries, setServerCountries] = (0,react_.useState)([]);
    const [visible, setVisible] = (0,react_.useState)(50);
    const search = state_useString("USA");
    const { selectedService, data, countries, countries_fetched, countries_loading } = (0,redux_store/* useReduxSelector */.M7)((s)=>s.services);
    (0,react_.useEffect)(()=>{
        if (countries_fetched) return;
        dispatch((0,requests/* fetchCountries */.t)(null));
    }, [
        dispatch,
        countries_fetched
    ]);
    (0,react_.useEffect)(()=>{
        if (!selectedService?.shortName) return;
        const getServiceCountries = Object.values(data[selectedService?.shortName]).map((obj)=>({
                ...obj,
                ...countries[obj.country] || {}
            }));
        setServerCountries(getServiceCountries);
    }, [
        data,
        selectedService,
        countries
    ]);
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "flex items-center justify-between",
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "flex items-center gap-2",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                className: "rounded",
                                src: selectedService?.logo,
                                width: 20,
                                height: 20,
                                alt: ``
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                dangerouslySetInnerHTML: {
                                    __html: selectedService?.name + `<small> (Verification) </small>` || 0
                                }
                            })
                        ]
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(node.IconButton, {
                        color: "warning",
                        onClick: ()=>dispatch(servicesSlice/* serviceActions */.C.removeSelectedService()),
                        children: /*#__PURE__*/ jsx_runtime_.jsx(common_FIcon/* default */.Z, {
                            icon: "times"
                        })
                    })
                ]
            }),
            countries_loading ? /*#__PURE__*/ jsx_runtime_.jsx(ListSkeleton, {
                count: 5,
                height: 75
            }) : /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "pt-4 pb-2",
                        children: /*#__PURE__*/ jsx_runtime_.jsx(MuiTextField/* default */.Z, {
                            name: "search country",
                            type: "search",
                            onChange: search.change,
                            value: search.value,
                            size: "small",
                            autoComplete: "off",
                            label: "Search country"
                        })
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "w-full h-[400px] max-h-full overflow-auto",
                        children: [
                            (search?.value?.length > 1 ? dynamic_filter(serviceCountries, [
                                "rus",
                                "eng",
                                "chn"
                            ], search.value) : serviceCountries.filter((_, i)=>i <= visible)).map((data)=>{
                                return data?.eng ? /*#__PURE__*/ jsx_runtime_.jsx(CountryDetailsByService, {
                                    service: data
                                }, (0,dist/* uid */.h)()) : null;
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx(WarningText, {
                                shouldShow: serviceCountries?.length === 0
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx(ShowAndLessButton, {
                                shouldHide: search?.value || serviceCountries.length === 0,
                                fullLength: serviceCountries.length,
                                showLength: visible,
                                onMore: ()=>setVisible((p)=>p + 20),
                                onLess: ()=>setVisible(50)
                            })
                        ]
                    })
                ]
            })
        ]
    });
}

;// CONCATENATED MODULE: ./src/app/dashboard/ServicesList.tsx
/* __next_internal_client_entry_do_not_use__ default auto */ 















function ServicesList() {
    const { services, loading, fetched, selectedService, visibleValue } = (0,redux_store/* useReduxSelector */.M7)((state)=>state.services);
    const dispatch = (0,redux_store/* useReduxDispatch */.Ns)();
    const search = state_useString("");
    (0,react_.useEffect)(()=>{
        if (fetched) return;
        dispatch((0,requests/* fetchServices */.Q)(null));
    }, [
        dispatch,
        fetched
    ]);
    (0,react_.useEffect)(()=>{
        if (!selectedService?.name || search?.value?.length < 2) return;
        if (search.value.length > 1) {
            dispatch(servicesSlice/* serviceActions */.C.removeSelectedService());
        }
    }, [
        search,
        dispatch,
        selectedService
    ]);
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(MuiTextField/* default */.Z, {
                type: "search",
                onChange: search.change,
                value: search.value,
                label: selectedService?.name ? "Select another service..." : "Search service..."
            }),
            selectedService?.name ? /*#__PURE__*/ jsx_runtime_.jsx(ManageSelectedService, {}) : /*#__PURE__*/ jsx_runtime_.jsx(Box["default"], {
                children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: "w-full h-[400px] max-h-full overflow-auto",
                    children: loading || !fetched ? /*#__PURE__*/ jsx_runtime_.jsx(ListSkeleton, {
                        count: 7,
                        height: 50
                    }) : /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
                        children: [
                            (search?.value?.length > 1 ? dynamic_filter(Object.values(services || {}), [
                                "name"
                            ], search.value) : Object.values(services).filter((_, i)=>i <= visibleValue))?.map((service)=>service?.name ? /*#__PURE__*/ jsx_runtime_.jsx((ListItem_default()), {
                                    component: "div",
                                    className: `w-full flex flex-col items-start justify-start`,
                                    children: /*#__PURE__*/ jsx_runtime_.jsx((ListItemButton_default()), {
                                        onClick: ()=>{
                                            dispatch(servicesSlice/* serviceActions */.C.setSelectedService(service));
                                            search.setCustom("");
                                        },
                                        className: "block w-full",
                                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                            className: "flex items-center gap-2",
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                                    className: "rounded",
                                                    src: service.logo,
                                                    width: 20,
                                                    height: 20,
                                                    alt: ``
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                    dangerouslySetInnerHTML: {
                                                        __html: service?.name || ""
                                                    }
                                                })
                                            ]
                                        })
                                    })
                                }, (0,dist/* uid */.h)()) : null),
                            /*#__PURE__*/ jsx_runtime_.jsx(ShowAndLessButton, {
                                shouldHide: search?.value,
                                fullLength: Object.keys(services).length,
                                showLength: visibleValue,
                                onMore: ()=>dispatch(servicesSlice/* serviceActions */.C.moreVisible(20)),
                                onLess: ()=>dispatch(servicesSlice/* serviceActions */.C.resetVisible())
                            })
                        ]
                    })
                })
            })
        ]
    });
}

;// CONCATENATED MODULE: ./src/app/dashboard/ServiceLeftbar.tsx




function ServiceLeftbar() {
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: "col-span-4 h-full p-8 bg-gray-100 dark:bg-gray-950 space-y-6",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(node.Typography, {
                variant: "h5",
                gutterBottom: true,
                children: "SMS Verifications"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                children: "Rent a phone for 5 minutes. Credits are only used if you receive the SMS code."
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(ServicesList, {})
        ]
    });
}

// EXTERNAL MODULE: ./node_modules/@mui/material/node/Table/index.js
var Table = __webpack_require__(77523);
var Table_default = /*#__PURE__*/__webpack_require__.n(Table);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/TableBody/index.js
var TableBody = __webpack_require__(24608);
var TableBody_default = /*#__PURE__*/__webpack_require__.n(TableBody);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/TableCell/index.js
var TableCell = __webpack_require__(80765);
var TableCell_default = /*#__PURE__*/__webpack_require__.n(TableCell);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/TableContainer/index.js
var TableContainer = __webpack_require__(68101);
var TableContainer_default = /*#__PURE__*/__webpack_require__.n(TableContainer);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/TablePagination/index.js
var TablePagination = __webpack_require__(15061);
var TablePagination_default = /*#__PURE__*/__webpack_require__.n(TablePagination);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/TableRow/index.js
var TableRow = __webpack_require__(44233);
var TableRow_default = /*#__PURE__*/__webpack_require__.n(TableRow);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/Paper/index.js
var Paper = __webpack_require__(52694);
var Paper_default = /*#__PURE__*/__webpack_require__.n(Paper);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/Checkbox/index.js
var Checkbox = __webpack_require__(16061);
var Checkbox_default = /*#__PURE__*/__webpack_require__.n(Checkbox);
// EXTERNAL MODULE: ./node_modules/@mui/utils/index.js
var utils = __webpack_require__(44268);
;// CONCATENATED MODULE: ./src/common/MaterialUi/MuiTable/MuiTableHead.tsx




function MuiTableHead({ onSelectAllClick, order, orderBy, numSelected, rowCount, onRequestSort, headCells, hideActions, hideCheckbox }) {
    const createSortHandler = (property)=>(event)=>{
            onRequestSort(event, property);
        };
    return /*#__PURE__*/ jsx_runtime_.jsx(node.TableHead, {
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(node.TableRow, {
            children: [
                hideCheckbox ? null : /*#__PURE__*/ jsx_runtime_.jsx(node.TableCell, {
                    padding: "checkbox",
                    children: /*#__PURE__*/ jsx_runtime_.jsx(node.Checkbox, {
                        color: "primary",
                        indeterminate: numSelected > 0 && numSelected < rowCount,
                        checked: rowCount > 0 && numSelected === rowCount,
                        onChange: onSelectAllClick,
                        inputProps: {
                            "aria-label": "select all desserts"
                        }
                    })
                }),
                headCells.map((headCell)=>/*#__PURE__*/ jsx_runtime_.jsx(node.TableCell, {
                        align: headCell.numeric ? "right" : "left",
                        padding: headCell.disablePadding ? "none" : "normal",
                        sortDirection: orderBy === headCell.key ? order : false,
                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(node.TableSortLabel, {
                            active: orderBy === headCell.key,
                            direction: orderBy === headCell.key ? order : "asc",
                            onClick: createSortHandler(headCell.key),
                            children: [
                                headCell.label,
                                orderBy === headCell.key ? /*#__PURE__*/ jsx_runtime_.jsx(node.Box, {
                                    component: "span",
                                    sx: utils.visuallyHidden,
                                    children: order === "desc" ? "sorted descending" : "sorted ascending"
                                }) : null
                            ]
                        })
                    }, headCell.key)),
                hideActions ? null : /*#__PURE__*/ jsx_runtime_.jsx(node.TableCell, {
                    children: "Actions"
                })
            ]
        })
    });
}

// EXTERNAL MODULE: ./node_modules/@mui/material/node/styles/index.js
var styles = __webpack_require__(83476);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/IconButton/index.js
var IconButton = __webpack_require__(48060);
var IconButton_default = /*#__PURE__*/__webpack_require__.n(IconButton);
// EXTERNAL MODULE: ./node_modules/@mui/icons-material/Delete.js
var Delete = __webpack_require__(30237);
// EXTERNAL MODULE: ./node_modules/@mui/icons-material/FilterList.js
var FilterList = __webpack_require__(89119);
;// CONCATENATED MODULE: ./src/hooks/useTracking.ts

function useTracking() {
    const [values, setValues] = (0,react_.useState)([
        "initial"
    ]);
    const start = (should)=>{
        if (should && values.length === 1) setValues([
            "initial",
            "start"
        ]);
    };
    const finish = (should)=>{
        if (should && values.length === 2) setValues([
            "initial",
            "start",
            "finished"
        ]);
    };
    return {
        values,
        setValues,
        start,
        finish,
        reset: ()=>setValues([
                "initial"
            ]),
        done: values.length === 3
    };
}

// EXTERNAL MODULE: ./node_modules/@mui/material/node/Button/index.js
var node_Button = __webpack_require__(16614);
var Button_default = /*#__PURE__*/__webpack_require__.n(node_Button);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/Dialog/index.js
var Dialog = __webpack_require__(62969);
var Dialog_default = /*#__PURE__*/__webpack_require__.n(Dialog);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/DialogContent/index.js
var DialogContent = __webpack_require__(16856);
var DialogContent_default = /*#__PURE__*/__webpack_require__.n(DialogContent);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/DialogTitle/index.js
var DialogTitle = __webpack_require__(42153);
var DialogTitle_default = /*#__PURE__*/__webpack_require__.n(DialogTitle);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/useMediaQuery/index.js
var useMediaQuery = __webpack_require__(72586);
;// CONCATENATED MODULE: ./src/common/MaterialUi/Modal/MuiConfirmationDialog.tsx








function MuiConfirmationDialog({ showModal, warningText, loading, onConfirm, confirmButtonText }) {
    const theme = (0,styles.useTheme)();
    const fullScreen = (0,useMediaQuery["default"])(theme.breakpoints.down("md"));
    const handleClose = ()=>{
        showModal.toggle();
    };
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)((Dialog_default()), {
        fullScreen: fullScreen,
        open: showModal?.true,
        onClose: handleClose,
        "aria-labelledby": "responsive-dialog-title",
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)((DialogTitle_default()), {
                className: "flex items-center gap-2 border-b border-b-slate-300 dark:border-b-slate-600 text-center text-xl font-semibold",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("svg", {
                        "aria-hidden": "true",
                        focusable: "false",
                        "data-prefix": "fas",
                        className: "w-6",
                        "data-icon": "triangle-exclamation",
                        role: "img",
                        xmlns: "http://www.w3.org/2000/svg",
                        viewBox: "0 0 512 512",
                        children: /*#__PURE__*/ jsx_runtime_.jsx("path", {
                            fill: "currentColor",
                            d: "M256 32c14.2 0 27.3 7.5 34.5 19.8l216 368c7.3 12.4 7.3 27.7 .2 40.1S486.3 480 472 480H40c-14.3 0-27.6-7.7-34.7-20.1s-7-27.8 .2-40.1l216-368C228.7 39.5 241.8 32 256 32zm0 128c-13.3 0-24 10.7-24 24V296c0 13.3 10.7 24 24 24s24-10.7 24-24V184c0-13.3-10.7-24-24-24zm32 224a32 32 0 1 0 -64 0 32 32 0 1 0 64 0z"
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                        children: "Confirmation"
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)((DialogContent_default()), {
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("h3", {
                        className: "p-4 text-center text-xl font-medium text-yellow-600",
                        children: warningText
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "relative md:min-w-[500px]",
                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: "flex justify-end gap-2 pt-5",
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx((Button_default()), {
                                    onClick: handleClose,
                                    type: "button",
                                    children: "Cancel"
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)((Button_default()), {
                                    disabled: loading,
                                    onClick: onConfirm,
                                    variant: "contained",
                                    className: "flex items-center gap-2",
                                    children: [
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("span", {
                                            children: [
                                                " ",
                                                confirmButtonText || "Submit",
                                                " "
                                            ]
                                        }),
                                        loading ? /*#__PURE__*/ jsx_runtime_.jsx(node.CircularProgress, {
                                            color: "inherit",
                                            size: 18
                                        }) : null
                                    ]
                                })
                            ]
                        })
                    })
                ]
            })
        ]
    });
}

;// CONCATENATED MODULE: ./src/common/MaterialUi/MuiTable/MuiTableHeadToolbar.tsx










function MuiTableHeadToolbar(props) {
    const { selected, tableTitle, onDeleteMultiple, deleting } = props;
    const showDeleteWarning = useBoolean();
    const tracking = useTracking();
    (0,react_.useEffect)(()=>{
        tracking.start(deleting?.true);
        tracking.finish(!deleting?.true);
    }, [
        tracking,
        deleting
    ]);
    (0,react_.useEffect)(()=>{
        if (tracking.done) {
            showDeleteWarning.setFalse();
            tracking.reset();
        }
    }, [
        showDeleteWarning,
        tracking
    ]);
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(MuiConfirmationDialog, {
                loading: deleting?.true,
                showModal: showDeleteWarning,
                warningText: `Want to delete all selected '${selected?.length}' items?`,
                onConfirm: ()=>onDeleteMultiple && onDeleteMultiple(selected),
                confirmButtonText: `Delete (${selected.length}) items!`
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)(node.Toolbar, {
                sx: {
                    pl: {
                        sm: 2
                    },
                    pr: {
                        xs: 1,
                        sm: 1
                    },
                    ...selected.length > 0 && {
                        bgcolor: (theme)=>(0,styles.alpha)(theme.palette.primary.main, theme.palette.action.activatedOpacity)
                    }
                },
                children: [
                    selected.length > 0 ? /*#__PURE__*/ (0,jsx_runtime_.jsxs)(node.Typography, {
                        sx: {
                            flex: "1 1 100%"
                        },
                        color: "inherit",
                        variant: "subtitle1",
                        component: "div",
                        children: [
                            selected.length,
                            " selected"
                        ]
                    }) : /*#__PURE__*/ jsx_runtime_.jsx(node.Typography, {
                        sx: {
                            flex: "1 1 100%"
                        },
                        variant: "h6",
                        id: "tableTitle",
                        component: "div",
                        children: tableTitle
                    }),
                    selected.length > 0 ? /*#__PURE__*/ jsx_runtime_.jsx(node.Tooltip, {
                        title: "Delete",
                        children: /*#__PURE__*/ jsx_runtime_.jsx((IconButton_default()), {
                            onClick: showDeleteWarning.setTrue,
                            children: /*#__PURE__*/ jsx_runtime_.jsx(Delete/* default */.Z, {})
                        })
                    }) : /*#__PURE__*/ jsx_runtime_.jsx(node.Tooltip, {
                        title: "Filter list",
                        children: /*#__PURE__*/ jsx_runtime_.jsx((IconButton_default()), {
                            children: /*#__PURE__*/ jsx_runtime_.jsx(FilterList/* default */.Z, {})
                        })
                    })
                ]
            })
        ]
    });
}

;// CONCATENATED MODULE: ./src/common/MaterialUi/MuiTable/functions.ts
function descendingComparator(a, b, orderBy) {
    if (b[orderBy] < a[orderBy]) {
        return -1;
    }
    if (b[orderBy] > a[orderBy]) {
        return 1;
    }
    return 0;
}
function getComparator(order, orderBy) {
    return order === "desc" ? (a, b)=>descendingComparator(a, b, orderBy) : (a, b)=>-descendingComparator(a, b, orderBy);
}
function stableSort(array, comparator) {
    const stabilizedThis = array.map((el, index)=>[
            el,
            index
        ]);
    stabilizedThis.sort((a, b)=>{
        const order = comparator(a[0], b[0]);
        if (order !== 0) {
            return order;
        }
        return a[1] - b[1];
    });
    return stabilizedThis.map((el)=>el[0]);
}

;// CONCATENATED MODULE: ./src/common/MaterialUi/MuiTable/MuiTable.tsx
/* __next_internal_client_entry_do_not_use__ default auto */ 















function MuiTable({ tableCells, rows, tableTitle, onDeleteMultiple, deleting, hideActions }) {
    const [order, setOrder] = react_default().useState("asc");
    const [orderBy, setOrderBy] = react_default().useState("name");
    const [selected, setSelected] = react_default().useState([]);
    const [page, setPage] = react_default().useState(0);
    const [rowsPerPage, setRowsPerPage] = react_default().useState(5);
    const handleRequestSort = (event, property)=>{
        const isAsc = orderBy === property && order === "asc";
        setOrder(isAsc ? "desc" : "asc");
        setOrderBy(property);
    };
    const handleSelectAllClick = (event)=>{
        if (event.target.checked) {
            const newSelected = rows.map((n)=>n.id);
            setSelected(newSelected);
            return;
        }
        setSelected([]);
    };
    const handleClick = (event, id)=>{
        const selectedIndex = selected.indexOf(id);
        let newSelected = [];
        if (selectedIndex === -1) {
            newSelected = newSelected.concat(selected, id);
        } else if (selectedIndex === 0) {
            newSelected = newSelected.concat(selected.slice(1));
        } else if (selectedIndex === selected.length - 1) {
            newSelected = newSelected.concat(selected.slice(0, -1));
        } else if (selectedIndex > 0) {
            newSelected = newSelected.concat(selected.slice(0, selectedIndex), selected.slice(selectedIndex + 1));
        }
        setSelected(newSelected);
    };
    const handleChangePage = (event, newPage)=>{
        setPage(newPage);
    };
    const handleChangeRowsPerPage = (event)=>{
        setRowsPerPage(parseInt(event.target.value, 10));
        setPage(0);
    };
    const isSelected = (id)=>selected.indexOf(id) !== -1;
    // Avoid a layout jump when reaching the last page with empty rows.
    const emptyRows = page > 0 ? Math.max(0, (1 + page) * rowsPerPage - rows.length) : 0;
    const visibleRows = react_default().useMemo(()=>stableSort(rows, getComparator(order, orderBy)).slice(page * rowsPerPage, page * rowsPerPage + rowsPerPage), [
        order,
        orderBy,
        page,
        rowsPerPage,
        rows
    ]);
    return /*#__PURE__*/ jsx_runtime_.jsx(Box["default"], {
        sx: {
            width: "100%"
        },
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)((Paper_default()), {
            sx: {
                width: "100%",
                mb: 2
            },
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx(MuiTableHeadToolbar, {
                    tableTitle: tableTitle,
                    selected: selected,
                    deleting: deleting,
                    onDeleteMultiple: onDeleteMultiple
                }),
                /*#__PURE__*/ jsx_runtime_.jsx((TableContainer_default()), {
                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)((Table_default()), {
                        "aria-labelledby": "tableTitle",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx(MuiTableHead, {
                                numSelected: selected.length,
                                order: order,
                                orderBy: orderBy,
                                onSelectAllClick: handleSelectAllClick,
                                onRequestSort: handleRequestSort,
                                rowCount: rows.length,
                                headCells: tableCells,
                                hideActions: hideActions
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)((TableBody_default()), {
                                children: [
                                    visibleRows.map((row, index)=>/*#__PURE__*/ (0,jsx_runtime_.jsxs)((TableRow_default()), {
                                            hover: true,
                                            onClick: (event)=>handleClick(event, row.id),
                                            role: "checkbox",
                                            "aria-checked": isSelected(row.id),
                                            tabIndex: -1,
                                            selected: isSelected(row.id),
                                            sx: {
                                                cursor: "pointer"
                                            },
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx((TableCell_default()), {
                                                    padding: "checkbox",
                                                    children: /*#__PURE__*/ jsx_runtime_.jsx((Checkbox_default()), {
                                                        color: "primary",
                                                        checked: isSelected(row.id)
                                                    })
                                                }),
                                                tableCells.map(({ key, RenderComponent, WrapperComponent, className, align })=>/*#__PURE__*/ jsx_runtime_.jsx((TableCell_default()), {
                                                        align: align,
                                                        className: className,
                                                        children: RenderComponent ? /*#__PURE__*/ jsx_runtime_.jsx(RenderComponent, {
                                                            row: row
                                                        }) : typeof row[key] === "object" ? index == 0 ? /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                            className: "max-w-[200px] text-yellow-600",
                                                            children: [
                                                                "Hey bro, this is got object, please use custom",
                                                                /*#__PURE__*/ jsx_runtime_.jsx("b", {
                                                                    children: " RenderComponent "
                                                                }),
                                                                "in tableCells",
                                                                /*#__PURE__*/ jsx_runtime_.jsx("pre", {
                                                                    className: "bg-black p-3 rounded text-yellow-300 mt-3",
                                                                    children: JSON.stringify(row[key], null, 2)
                                                                })
                                                            ]
                                                        }) : null : WrapperComponent ? /*#__PURE__*/ jsx_runtime_.jsx(WrapperComponent, {
                                                            row: row,
                                                            children: row[key]
                                                        }) : row[key]
                                                    }, key)),
                                                hideActions ? null : /*#__PURE__*/ jsx_runtime_.jsx((TableCell_default()), {
                                                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                        className: "space-x-1",
                                                        children: [
                                                            /*#__PURE__*/ jsx_runtime_.jsx(node.Button, {
                                                                color: "warning",
                                                                variant: "contained",
                                                                size: "small",
                                                                startIcon: /*#__PURE__*/ jsx_runtime_.jsx(common_FIcon/* default */.Z, {
                                                                    icon: "pencil",
                                                                    className: "w-3"
                                                                }),
                                                                children: "Edit"
                                                            }),
                                                            /*#__PURE__*/ jsx_runtime_.jsx(node.Button, {
                                                                color: "info",
                                                                variant: "contained",
                                                                size: "small",
                                                                startIcon: /*#__PURE__*/ jsx_runtime_.jsx(common_FIcon/* default */.Z, {
                                                                    icon: "trash",
                                                                    className: "w-3"
                                                                }),
                                                                children: "Delete"
                                                            })
                                                        ]
                                                    })
                                                })
                                            ]
                                        }, row.id)),
                                    emptyRows > 0 && /*#__PURE__*/ jsx_runtime_.jsx((TableRow_default()), {
                                        style: {
                                            height: 53 * emptyRows
                                        },
                                        children: /*#__PURE__*/ jsx_runtime_.jsx((TableCell_default()), {
                                            colSpan: 6
                                        })
                                    })
                                ]
                            })
                        ]
                    })
                }),
                /*#__PURE__*/ jsx_runtime_.jsx((TablePagination_default()), {
                    rowsPerPageOptions: [
                        5,
                        10,
                        25
                    ],
                    component: "div",
                    count: rows.length,
                    rowsPerPage: rowsPerPage,
                    page: page,
                    onPageChange: handleChangePage,
                    onRowsPerPageChange: handleChangeRowsPerPage
                })
            ]
        })
    });
}

;// CONCATENATED MODULE: ./src/hooks/useCopy.ts

function useCopy() {
    const [copiedText, setCopiedText] = (0,react_.useState)(null);
    const [isCopied, setIsCopied] = (0,react_.useState)(false);
    const copy = async (text)=>{
        if (!navigator?.clipboard) {
            console.warn("Clipboard not supported");
            return false;
        }
        try {
            await navigator.clipboard.writeText(text || "");
            setCopiedText(text || "");
            setIsCopied(true);
            setTimeout(()=>{
                setIsCopied(false);
            }, 2000);
            return true;
        } catch (error) {
            console.warn("Copy failed", error);
            setCopiedText(null);
            return false;
        }
    };
    return {
        copiedText,
        copy,
        isCopied
    };
}
/* harmony default export */ const hooks_useCopy = (useCopy);

;// CONCATENATED MODULE: ./src/lib/delay.ts
function delay(time) {
    return new Promise((r)=>setTimeout(()=>r(1), time));
}

;// CONCATENATED MODULE: ./src/app/dashboard/ServiceRightbar.tsx
/* __next_internal_client_entry_do_not_use__ default,RefreshCode auto */ 










const ServiceDetails = ({ row })=>{
    const { copy, isCopied } = hooks_useCopy();
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: "flex items-center gap-2",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                className: "dark:rounded-lg",
                src: row.service_logo,
                alt: "",
                width: 28,
                height: 28
            }),
            /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                src: row.country_logo,
                alt: "",
                width: 28,
                height: 28
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)(node.Button, {
                title: "Copy Number",
                className: "flex items-center gap-1",
                onClick: ()=>copy(row?.phoneNumber),
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                        children: row?.phoneNumber
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                        children: isCopied ? /*#__PURE__*/ jsx_runtime_.jsx(common_FIcon/* default */.Z, {
                            icon: "check"
                        }) : /*#__PURE__*/ jsx_runtime_.jsx(common_FIcon/* default */.Z, {
                            icon: "clipboard"
                        })
                    })
                ]
            })
        ]
    });
};
const CodeAndStatus = ({ row })=>{
    const { copy, isCopied } = hooks_useCopy();
    return /*#__PURE__*/ jsx_runtime_.jsx("div", {
        className: "flex items-center gap-1",
        children: row.sms_code?.length ? /*#__PURE__*/ (0,jsx_runtime_.jsxs)(node.Button, {
            title: "Copy Code",
            className: "flex items-center gap-1",
            onClick: ()=>copy(row?.sms_code[row?.sms_code?.length - 1]),
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx("span", {
                    children: row.sms_code[row.sms_code?.length - 1]
                }),
                /*#__PURE__*/ jsx_runtime_.jsx("span", {
                    children: isCopied ? /*#__PURE__*/ jsx_runtime_.jsx(common_FIcon/* default */.Z, {
                        icon: "check"
                    }) : /*#__PURE__*/ jsx_runtime_.jsx(common_FIcon/* default */.Z, {
                        icon: "clipboard"
                    })
                })
            ]
        }) : row.status === "STATUS_WAIT_CODE" ? /*#__PURE__*/ jsx_runtime_.jsx("div", {
            className: "animate-spin",
            children: /*#__PURE__*/ jsx_runtime_.jsx(node.IconButton, {
                size: "small",
                children: /*#__PURE__*/ jsx_runtime_.jsx(common_FIcon/* default */.Z, {
                    icon: "refresh"
                })
            })
        }) : /*#__PURE__*/ (0,jsx_runtime_.jsxs)("span", {
            children: [
                " ",
                row.status,
                " "
            ]
        })
    });
};
const tableCells = [
    {
        key: "service_logo",
        label: "Service Details",
        RenderComponent ({ row }) {
            return /*#__PURE__*/ jsx_runtime_.jsx(ServiceDetails, {
                row: row
            });
        }
    },
    {
        key: "cost",
        label: "Cost",
        RenderComponent ({ row }) {
            return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                children: [
                    row.cost,
                    " ₽"
                ]
            });
        }
    },
    {
        key: "status",
        label: "Status/Code",
        RenderComponent ({ row }) {
            return /*#__PURE__*/ jsx_runtime_.jsx(CodeAndStatus, {
                row: row
            });
        }
    }
];
function ServiceRightbar() {
    const { data } = (0,redux_store/* useReduxSelector */.M7)((s)=>s.activations);
    const deleting = useBoolean();
    const getCode = useGetActivationsCode();
    async function onDelete(ids) {
        deleting.setTrue();
        await delay(3000);
        console.log("IDs[] ", ids);
        deleting.setFalse();
    }
    const getCodeCalled = useBoolean();
    (0,react_.useEffect)(()=>{
        getCodeCalled.setTrue();
        if (getCodeCalled.true) return;
        getCode();
    }, [
        getCode,
        getCodeCalled
    ]);
    return /*#__PURE__*/ jsx_runtime_.jsx("div", {
        className: "col-span-8 bg-white dark:bg-gray-800",
        children: /*#__PURE__*/ jsx_runtime_.jsx(MuiTable, {
            onDeleteMultiple: onDelete,
            tableCells: tableCells,
            rows: data,
            tableTitle: "Activations",
            deleting: deleting,
            hideActions: true
        })
    });
}
function RefreshCode() {
    return /*#__PURE__*/ _jsx("div", {
        children: /*#__PURE__*/ _jsx(Button, {
            children: /*#__PURE__*/ _jsx(FIcon, {
                icon: "trash"
            })
        })
    });
}

;// CONCATENATED MODULE: ./src/app/dashboard/page.tsx
/* __next_internal_client_entry_do_not_use__ default auto */ 



function Dashboard() {
    return /*#__PURE__*/ jsx_runtime_.jsx("div", {
        className: "container py-20",
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
            className: "lg:grid grid-cols-12 h-fit max-h-screen",
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx(ServiceLeftbar, {}),
                /*#__PURE__*/ jsx_runtime_.jsx(ServiceRightbar, {})
            ]
        })
    });
}


/***/ }),

/***/ 40696:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (/* binding */ toast)
/* harmony export */ });
/* harmony import */ var react_toastify__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(34751);

function toast({ message, type, duration }) {
    react_toastify__WEBPACK_IMPORTED_MODULE_0__/* .toast */ .Am[type || "success"](message, {
        position: "top-center",
        autoClose: duration || 1500,
        hideProgressBar: false,
        closeOnClick: true,
        pauseOnHover: true,
        draggable: true,
        progress: undefined
    });
}


/***/ }),

/***/ 64644:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   $$typeof: () => (/* binding */ $$typeof),
/* harmony export */   __esModule: () => (/* binding */ __esModule),
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var next_dist_build_webpack_loaders_next_flight_loader_module_proxy__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(61363);

const proxy = (0,next_dist_build_webpack_loaders_next_flight_loader_module_proxy__WEBPACK_IMPORTED_MODULE_0__.createProxy)(String.raw`S:\Web Applications\NextJS\YenSMS\src\app\dashboard\page.tsx`)

// Accessing the __esModule property and exporting $$typeof are required here.
// The __esModule getter forces the proxy target to create the default export
// and the $$typeof value is for rendering logic to determine if the module
// is a client boundary.
const { __esModule, $$typeof } = proxy;
const __default__ = proxy.default;


/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (__default__);

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [3587,8425,3258,4815,9056,4389], () => (__webpack_exec__(41362)));
module.exports = __webpack_exports__;

})();