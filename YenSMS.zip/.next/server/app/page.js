(() => {
var exports = {};
exports.id = 1931;
exports.ids = [1931];
exports.modules = {

/***/ 18038:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react");

/***/ }),

/***/ 98704:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react-dom/server-rendering-stub");

/***/ }),

/***/ 97897:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react-server-dom-webpack/client");

/***/ }),

/***/ 56786:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react/jsx-runtime");

/***/ }),

/***/ 5868:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/app-render/app-render");

/***/ }),

/***/ 41844:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/app-render/get-segment-param");

/***/ }),

/***/ 96624:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/future/helpers/interception-routes");

/***/ }),

/***/ 75281:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/future/route-modules/route-module");

/***/ }),

/***/ 57085:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/app-router-context");

/***/ }),

/***/ 1830:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/get-img-props");

/***/ }),

/***/ 20199:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/hash");

/***/ }),

/***/ 66864:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/head");

/***/ }),

/***/ 39569:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/hooks-client-context");

/***/ }),

/***/ 52210:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config");

/***/ }),

/***/ 35359:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config-context");

/***/ }),

/***/ 17160:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router-context");

/***/ }),

/***/ 30893:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/add-path-prefix");

/***/ }),

/***/ 12336:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/format-url");

/***/ }),

/***/ 17887:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/handle-smooth-scroll");

/***/ }),

/***/ 98735:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-bot");

/***/ }),

/***/ 60120:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-local-url");

/***/ }),

/***/ 68231:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-path");

/***/ }),

/***/ 54614:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/path-has-prefix");

/***/ }),

/***/ 53750:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash");

/***/ }),

/***/ 70982:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/resolve-href");

/***/ }),

/***/ 79618:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/server-inserted-html");

/***/ }),

/***/ 78423:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils");

/***/ }),

/***/ 98658:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils/warn-once");

/***/ }),

/***/ 71017:
/***/ ((module) => {

"use strict";
module.exports = require("path");

/***/ }),

/***/ 57310:
/***/ ((module) => {

"use strict";
module.exports = require("url");

/***/ }),

/***/ 98381:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   GlobalError: () => (/* reexport default from dynamic */ next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_2___default.a),
/* harmony export */   __next_app__: () => (/* binding */ __next_app__),
/* harmony export */   originalPathname: () => (/* binding */ originalPathname),
/* harmony export */   pages: () => (/* binding */ pages),
/* harmony export */   routeModule: () => (/* binding */ routeModule),
/* harmony export */   tree: () => (/* binding */ tree)
/* harmony export */ });
/* harmony import */ var next_dist_server_future_route_modules_app_page_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(7262);
/* harmony import */ var next_dist_server_future_route_modules_app_page_module__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_dist_server_future_route_modules_app_page_module__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_dist_server_future_route_kind__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(19513);
/* harmony import */ var next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(31823);
/* harmony import */ var next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(12502);
/* harmony import */ var next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_3__);
/* harmony reexport (unknown) */ var __WEBPACK_REEXPORT_OBJECT__ = {};
/* harmony reexport (unknown) */ for(const __WEBPACK_IMPORT_KEY__ in next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_3__) if(["default","tree","pages","GlobalError","originalPathname","__next_app__","routeModule"].indexOf(__WEBPACK_IMPORT_KEY__) < 0) __WEBPACK_REEXPORT_OBJECT__[__WEBPACK_IMPORT_KEY__] = () => next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_3__[__WEBPACK_IMPORT_KEY__]
/* harmony reexport (unknown) */ __webpack_require__.d(__webpack_exports__, __WEBPACK_REEXPORT_OBJECT__);
// @ts-ignore this need to be imported from next/dist to be external


const AppPageRouteModule = next_dist_server_future_route_modules_app_page_module__WEBPACK_IMPORTED_MODULE_0__.AppPageRouteModule;
// We inject the tree and pages here so that we can use them in the route
// module.
const tree = {
        children: [
        '',
        {
        children: ['__PAGE__', {}, {
          page: [() => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 78159)), "S:\\Web Applications\\NextJS\\YenSMS\\src\\app\\page.tsx"],
          metadata: {
    icon: [(async (props) => (await Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 73881))).default(props))],
    apple: [],
    openGraph: [],
    twitter: [],
    manifest: undefined
  }
        }]
      },
        {
          'layout': [() => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 86334)), "S:\\Web Applications\\NextJS\\YenSMS\\src\\app\\layout.tsx"],
'loading': [() => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 88924)), "S:\\Web Applications\\NextJS\\YenSMS\\src\\app\\loading.tsx"],
          metadata: {
    icon: [(async (props) => (await Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 73881))).default(props))],
    apple: [],
    openGraph: [],
    twitter: [],
    manifest: undefined
  }
        }
      ]
      }.children;
const pages = ["S:\\Web Applications\\NextJS\\YenSMS\\src\\app\\page.tsx"];

// @ts-expect-error - replaced by webpack/turbopack loader

const __next_app_require__ = __webpack_require__
const __next_app_load_chunk__ = () => Promise.resolve()
const originalPathname = "/page";
const __next_app__ = {
    require: __next_app_require__,
    loadChunk: __next_app_load_chunk__
};

// Create and export the route module that will be consumed.
const routeModule = new AppPageRouteModule({
    definition: {
        kind: next_dist_server_future_route_kind__WEBPACK_IMPORTED_MODULE_1__.RouteKind.APP_PAGE,
        page: "/page",
        pathname: "/",
        // The following aren't used in production.
        bundlePath: "",
        filename: "",
        appPaths: []
    },
    userland: {
        loaderTree: tree
    }
});

//# sourceMappingURL=app-page.js.map

/***/ }),

/***/ 41613:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 72834))

/***/ }),

/***/ 72834:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ Home)
});

// EXTERNAL MODULE: external "next/dist/compiled/react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(56786);
// EXTERNAL MODULE: ./src/common/FIcon.tsx
var FIcon = __webpack_require__(42635);
// EXTERNAL MODULE: ./node_modules/@szhsin/react-accordion/dist/cjs/index.js
var cjs = __webpack_require__(20251);
// EXTERNAL MODULE: external "next/dist/compiled/react"
var react_ = __webpack_require__(18038);
;// CONCATENATED MODULE: ./src/components/client/landing/FAQSection.tsx




const AccordionItem = ({ header, ...rest })=>/*#__PURE__*/ jsx_runtime_.jsx(cjs/* AccordionItem */.Qd, {
        ...rest,
        header: ({ state: { isEnter } })=>/*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "w-full flex items-center justify-between",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("h6", {
                        className: "px-2",
                        children: header
                    }),
                    isEnter ? /*#__PURE__*/ jsx_runtime_.jsx(FIcon/* default */.Z, {
                        icon: "chevron-up"
                    }) : /*#__PURE__*/ jsx_runtime_.jsx(FIcon/* default */.Z, {
                        icon: "chevron-down"
                    })
                ]
            }),
        className: "border-b",
        buttonProps: {
            className: ({ isEnter })=>`flex w-full p-4 text-left  ${isEnter && "bg-slate-200 dark:bg-gray-800"}`
        },
        contentProps: {
            className: "transition-height duration-200 ease-out"
        },
        panelProps: {
            className: "p-4"
        }
    });
function FAQSection() {
    return /*#__PURE__*/ jsx_runtime_.jsx("section", {
        className: "landing_section",
        id: "faq",
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
            className: "container",
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: "flex flex-wrap -mx-4",
                    children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "w-full px-4",
                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: "mx-auto mb-12 max-w-[510px] text-center lg:mb-20",
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                    className: "section_sub_title",
                                    children: "FREQUENTLY ASKED QUESTIONS"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("h2", {
                                    className: "section_title",
                                    children: "Take a look at the most asked questions."
                                })
                            ]
                        })
                    })
                }),
                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: "my-4 border-t lg:w-[800px] mx-auto",
                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(cjs/* Accordion */.UQ, {
                        transition: true,
                        transitionTimeout: 200,
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx(AccordionItem, {
                                header: "What does We provides??",
                                initialEntered: true,
                                children: "Simply, it is a virtual number service that you can receive SMS from various websites. When you don`t feel comfortable sharing your personal number to register on a website, you can use one of our disposable numbers to receive text messages. There are many more use cases for virtual numbers. You can receive an SMS via our service for any reason you need."
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx(AccordionItem, {
                                header: "Does virtual numbers trustworthy?",
                                children: "Our virtual number service is 100% secure. The numbers you receive SMS are disposable virtual numbers for one-time use only and cannot be used again for any reason. If you would like to receive multiple SMS to the same number, you can use our rental service. We don`t collect any personal information at all so it is not possible for us to share your personal information with third parties."
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx(AccordionItem, {
                                header: "Can I use the same number again?",
                                children: "We have two different services for that matter. With the regular SMS service, the numbers are disposable SMS numbers for one-time use only. Therefore it is not possible to receive another SMS to the same number again. However, with the rental service, you can receive as many SMS as you want during the rental time. Which can be rented from 4 hours to 8 weeks."
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx(AccordionItem, {
                                header: "What happens if I don't receive an SMS?",
                                children: "You will get a full refund! If you don`t receive the SMS you expect for any reason in 10 minutes from the time of your order, your order will be cancelled and full amount will be refunded to your account automatically. It is also possible to cancel the number you purchased without any reason and get full amount refunded to your account immediately."
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx(AccordionItem, {
                                header: "Why should I use virtual SMS numbers?",
                                children: "The main reason is privacy. When you register on a website or a service that you need to use regularly or one-time only, you don`t feel comfortable sharing your personal phone number to verify your identity. With our virtual number service, you can instantly choose a number and get SMS from the service you would like to use and protect your privacy."
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx(AccordionItem, {
                                header: "What is number rental service?",
                                children: "If you don`t want to receive a single SMS to a disposable virtual number, you can rent similar virtual numbers to receive unlimited SMS to the rented number during the rental time. It is possible to rent a virtual number from 4 hours to 8 weeks. Long-term rentals are better for cases like when websites require 2FA to log in to your account or OTP for taking important actions on your account."
                            })
                        ]
                    })
                })
            ]
        })
    });
}

// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(52451);
var image_default = /*#__PURE__*/__webpack_require__.n(next_image);
;// CONCATENATED MODULE: ./src/components/client/landing/FeaturesSection.tsx



const FeatureCard = ({ image, title, details })=>{
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: "flex items-start gap-2",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "pt-1 pr-3",
                children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: "min-w-[45px] w-full bg-black bg-opacity-80 p-2 rounded shadow",
                    children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                        src: image,
                        width: 45,
                        height: 45,
                        alt: "feature"
                    })
                })
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("h4", {
                        className: "text-xl font-semibold text-dark",
                        children: title
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                        className: "text-body-color lg:max-w-[80%]",
                        children: details
                    })
                ]
            })
        ]
    });
};
function FeaturesSection() {
    return /*#__PURE__*/ jsx_runtime_.jsx("section", {
        id: "features",
        className: "landing_section2",
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
            className: "container",
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: "flex flex-wrap -mx-4",
                    children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "w-full px-4",
                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: "mx-auto mb-12 max-w-[510px] text-center lg:mb-20",
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                    className: "section_sub_title",
                                    children: "Features"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("h2", {
                                    className: "section_title",
                                    children: "Developed for you"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                    className: "pt-2",
                                    children: "Advanced Security with Swift Verification: Experience the Ease and Reliability of Instant SMS Verification for Your Peace of Mind."
                                })
                            ]
                        })
                    })
                }),
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: "grid sm:grid-cols-2 lg:grid-cols-2 2xl:grid-cols-3 gap-8 lg:gap-10 2xl:gap-16",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx(FeatureCard, {
                            title: "Safe and Guaranteed",
                            details: "We provide a 100% guaranteed SMS confirmation service. If you don't receive the SMS, full amount will be refunded!",
                            image: "medal.svg"
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx(FeatureCard, {
                            title: "Customer Satisfaction",
                            details: "Our main priority is to provide the best service to our customers. You only pay when you receive the text message.",
                            image: "target.svg"
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx(FeatureCard, {
                            title: "Uninterrupted Support",
                            details: "We are always here. If you have a problem, you can always open a ticket from your customer panel.",
                            image: "clock-3.svg"
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx(FeatureCard, {
                            title: "Advanced API Systemn",
                            details: "We have prepared a detailed API documentation for developers! You can use all services with our free API.",
                            image: "shop-2.svg"
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx(FeatureCard, {
                            title: "Reliable Payment Methods",
                            details: "Safely top-up your account. We do not store your card details. Pay with your credit/debit card or cryptocurrency.",
                            image: "team.svg"
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx(FeatureCard, {
                            title: "Fully Automated System",
                            details: "All orders are delivered automatically. You can top-up your account and start receiving SMS immediately.",
                            image: "check.svg"
                        })
                    ]
                })
            ]
        })
    });
}

// EXTERNAL MODULE: ./node_modules/framer-motion/dist/es/render/dom/motion.mjs + 149 modules
var motion = __webpack_require__(81110);
// EXTERNAL MODULE: ./node_modules/@lottiefiles/react-lottie-player/dist/lottie-react.js
var lottie_react = __webpack_require__(67875);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(11440);
var link_default = /*#__PURE__*/__webpack_require__.n(next_link);
// EXTERNAL MODULE: ./src/common/MaterialUi/MuiButton.tsx
var MuiButton = __webpack_require__(86011);
;// CONCATENATED MODULE: ./src/components/client/landing/HeroSection.tsx






const visible = {
    opacity: 1,
    y: 0,
    transition: {
        duration: 0.5
    }
};
const itemVariants = {
    hidden: {
        opacity: 0,
        y: 10
    },
    visible
};
function HeroSection() {
    const constraintsRef = (0,react_.useRef)(null);
    return /*#__PURE__*/ jsx_runtime_.jsx("div", {
        className: "bg-white dark:bg-gray-900",
        children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
            className: "container",
            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(motion/* motion */.E.div, {
                initial: "hidden",
                animate: "visible",
                exit: {
                    opacity: 0,
                    transition: {
                        duration: 1
                    }
                },
                variants: {
                    visible: {
                        transition: {
                            staggerChildren: 0.3
                        }
                    }
                },
                className: "relative isolate grid grid-cols-12",
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "col-span-4 flex items-center justify-end",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx(motion/* motion */.E.div, {
                                className: "drag-area",
                                ref: constraintsRef
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx(motion/* motion */.E.div, {
                                animate: {
                                    y: [
                                        -10,
                                        10
                                    ]
                                },
                                transition: {
                                    duration: 3,
                                    repeat: Infinity,
                                    repeatType: "reverse"
                                },
                                drag: true,
                                dragConstraints: constraintsRef,
                                children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: "-ml-10",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx(lottie_react/* Player */.J5, {
                                        autoplay: true,
                                        loop: true,
                                        src: "/data/mobile-technology.json",
                                        style: {
                                            height: "500px"
                                        }
                                    })
                                })
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "col-span-8",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "mx-auto max-w-2xl py-32 sm:py-48 lg:py-56",
                                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    className: "text-center",
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx(motion/* motion */.E.h1, {
                                            variants: {
                                                hidden: {
                                                    opacity: 0,
                                                    y: -20
                                                },
                                                visible
                                            },
                                            className: "text-left text-4xl font-bold tracking-tight sm:text-6xl",
                                            children: "Receive Online SMS with Virtual Number Service"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx(motion/* motion */.E.p, {
                                            variants: itemVariants,
                                            className: "mt-6 text-lg leading-8 text-left",
                                            children: "Use our disposable phone number service to verify your accounts. Cheap and reliable SMS verification service. Pay with credit/debit card or cryptocurrency."
                                        }),
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)(motion/* motion */.E.div, {
                                            variants: itemVariants,
                                            className: "mt-10 flex items-center justify-start gap-x-6",
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx(motion/* motion */.E.div, {
                                                    whileHover: {
                                                        scale: 1.05
                                                    },
                                                    whileTap: {
                                                        scale: 0.9
                                                    },
                                                    children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                        href: "/dashboard",
                                                        children: /*#__PURE__*/ jsx_runtime_.jsx(MuiButton/* default */.Z, {
                                                            color: "secondary",
                                                            children: "Dashboard"
                                                        })
                                                    })
                                                }),
                                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)((link_default()), {
                                                    href: "/signin",
                                                    className: "text-sm font-semibold leading-6 group",
                                                    children: [
                                                        "Signin",
                                                        /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                            "aria-hidden": "true",
                                                            className: "group-hover:pl-2",
                                                            children: "→"
                                                        })
                                                    ]
                                                })
                                            ]
                                        })
                                    ]
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "absolute inset-x-0 top-[calc(100%-13rem)] -z-10 transform-gpu overflow-hidden blur-3xl sm:top-[calc(100%-30rem)]",
                                "aria-hidden": "true"
                            })
                        ]
                    })
                ]
            })
        })
    });
}

// EXTERNAL MODULE: ./node_modules/@headlessui/react/dist/components/tabs/tabs.js + 3 modules
var tabs = __webpack_require__(46342);
;// CONCATENATED MODULE: ./src/components/client/landing/HowItWorksTabs.tsx




function classNames(...classes) {
    return classes.filter(Boolean).join(" ");
}
function HowItWorksTabs() {
    let [categories] = (0,react_.useState)({
        Service: [
            {
                id: 1,
                text: "Indicate your preference by selecting the specific website from which you would like to receive SMS notifications. Keep updated and engaged with the content that matters most to you, directly through SMS alerts."
            }
        ],
        Country: [
            {
                id: 1,
                text: "Choose the country that aligns with your preference, and select it as the origin for your phone number. This step ensures you get a number that corresponds to your desired location and facilitates seamless communication."
            }
        ],
        "Make Payment": [
            {
                id: 1,
                text: "Easily and confidently replenish your account balance to successfully finalize your order. Our secure top-up process guarantees that your transactions are safeguarded, allowing you to swiftly proceed with your purchase without any concerns about payment."
            }
        ]
    });
    return /*#__PURE__*/ jsx_runtime_.jsx(motion/* motion */.E.div, {
        initial: "hidden",
        animate: "visible",
        exit: {
            opacity: 0,
            transition: {
                duration: 1
            }
        },
        variants: {
            visible: {
                transition: {
                    staggerChildren: 0.3
                }
            }
        },
        className: "w-full py-6",
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(tabs/* Tab */.O.Group, {
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx(tabs/* Tab */.O.List, {
                    className: "flex space-x-1 rounded-xl bg-blue-900/20 p-1",
                    children: Object.keys(categories).map((category)=>/*#__PURE__*/ jsx_runtime_.jsx(tabs/* Tab */.O, {
                            className: ({ selected })=>classNames("w-full rounded-lg py-2.5 text-sm font-medium leading-5 text-blue-700", "ring-white ring-opacity-60 ring-offset-2 ring-offset-blue-400 focus:outline-none focus:ring-2", selected ? "bg-white shadow" : "text-blue-100 hover:bg-white/[0.12] hover:text-white"),
                            children: category
                        }, category))
                }),
                /*#__PURE__*/ jsx_runtime_.jsx(tabs/* Tab */.O.Panels, {
                    className: "mt-2",
                    children: Object.values(categories).map((posts, idx)=>/*#__PURE__*/ jsx_runtime_.jsx(tabs/* Tab */.O.Panel, {
                            className: classNames("rounded-xl bg-white dark:bg-gray-800 p-3", "ring-white ring-opacity-60 ring-offset-2 ring-offset-blue-400 focus:outline-none focus:ring-2"),
                            children: /*#__PURE__*/ jsx_runtime_.jsx("ul", {
                                children: posts.map((post)=>/*#__PURE__*/ jsx_runtime_.jsx("li", {
                                        className: "relative rounded-md p-3 hover:bg-gray-100 dark:hover:bg-gray-700",
                                        children: /*#__PURE__*/ jsx_runtime_.jsx(motion/* motion */.E.p, {
                                            variants: {
                                                hidden: {
                                                    opacity: 0,
                                                    y: -20
                                                },
                                                visible: {
                                                    opacity: 1,
                                                    y: 0,
                                                    transition: {
                                                        duration: 1
                                                    }
                                                }
                                            },
                                            children: post.text
                                        })
                                    }, post.id))
                            })
                        }, idx))
                })
            ]
        })
    });
}

;// CONCATENATED MODULE: ./src/components/client/landing/HowItWorks.tsx




function HowItWorks() {
    return /*#__PURE__*/ jsx_runtime_.jsx("section", {
        id: "how-it-works",
        className: "landing_section2",
        children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
            className: "container px-4 mx-auto",
            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "grid grid-cols-1 xl:grid-cols-12",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "col-span-6 hidden xl:flex justify-normal items-center",
                        children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                            src: "/how-it-works.jpg",
                            className: "rounded-xl mx-auto transform rotate-6 border dark:border-transparent",
                            width: 450,
                            height: 450,
                            alt: "how it works?"
                        })
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "xl:col-span-6",
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "max-w-xl text-center mx-auto",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("h2", {
                                        className: "section_title",
                                        children: "Start receiving SMS quickly by following simple steps."
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                        children: "Our system works fully automatic. You can start receiving sms by topping up your account. If you have any problem or questions, you can always open a ticket from your customer panel."
                                    })
                                ]
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx(HowItWorksTabs, {})
                        ]
                    })
                ]
            })
        })
    });
}

;// CONCATENATED MODULE: ./src/components/client/landing/ServiceSection.tsx




const ServiceCard = ({ icon, title, details })=>{
    return /*#__PURE__*/ jsx_runtime_.jsx(jsx_runtime_.Fragment, {
        children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
            className: "w-full text-center bg-[#00000009] dark:bg-[#ffffff09]",
            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "p-4 space-y-2",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("h1", {
                        className: "text-3xl",
                        children: /*#__PURE__*/ jsx_runtime_.jsx(FIcon/* default */.Z, {
                            icon: icon
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("h4", {
                        className: "text-xl font-semibold text-dark",
                        children: title
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                        className: "text-body-color",
                        children: details
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "w-fit mx-auto",
                        children: /*#__PURE__*/ jsx_runtime_.jsx(MuiButton/* default */.Z, {
                            children: "Verify"
                        })
                    })
                ]
            })
        })
    });
};
function ServiceSection() {
    return /*#__PURE__*/ jsx_runtime_.jsx("section", {
        className: "landing_section shadow border-t dark:border-[#ffffff1e]",
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
            className: "container",
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: "flex flex-wrap -mx-4",
                    children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "w-full px-4",
                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: "mx-auto mb-12 max-w-[510px] text-center lg:mb-20",
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                    className: "section_sub_title",
                                    children: "POPULAR SERVICES"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("h2", {
                                    className: "section_title",
                                    children: "Most Popular Services"
                                })
                            ]
                        })
                    })
                }),
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: "grid sm:grid-cols-2 lg:grid-cols-3 gap-6",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx(ServiceCard, {
                            title: "Facebook Verification",
                            details: "Verify your Facebook account using our virtual phone numbers. Facebook sms verification starts from $0.05.",
                            icon: "facebook"
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx(ServiceCard, {
                            title: "Twitter Verification",
                            details: "Verify your Twitter account using our virtual phone numbers. Twitter sms verification starts from $0.05.",
                            icon: "twitter"
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx(ServiceCard, {
                            title: "Telegram Verification",
                            details: "Verify your Telegram account using our virtual phone numbers. Telegram sms verification starts from $0.5.",
                            icon: "telegram"
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx(ServiceCard, {
                            title: "Whatsapp Verification",
                            details: "Verify your Whatsapp account using our virtual phone numbers. Whatsapp sms verification starts from $0.82.",
                            icon: "whatsapp"
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx(ServiceCard, {
                            title: "Discord Verification",
                            details: "Verify your Discord account using our virtual phone numbers. Discord sms verification starts from $0.05.",
                            icon: "whatsapp"
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx(ServiceCard, {
                            title: "Instagram Verification",
                            details: "Verify your Instagram account using our virtual phone numbers. Instagram sms verification starts from $0.05.",
                            icon: "instagram"
                        })
                    ]
                })
            ]
        })
    });
}

// EXTERNAL MODULE: ./node_modules/framer-motion/dist/es/value/use-scroll.mjs + 12 modules
var use_scroll = __webpack_require__(54997);
// EXTERNAL MODULE: ./node_modules/framer-motion/dist/es/value/use-spring.mjs + 1 modules
var use_spring = __webpack_require__(85772);
;// CONCATENATED MODULE: ./src/app/page.tsx
/* __next_internal_client_entry_do_not_use__ default auto */ 






function Home() {
    const { scrollYProgress } = (0,use_scroll/* useScroll */.v)();
    const scaleX = (0,use_spring/* useSpring */.q)(scrollYProgress, {
        stiffness: 100,
        damping: 30,
        restDelta: 0.001
    });
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(motion/* motion */.E.div, {
                className: "fixed inset-x-0 top-0 h-[2px] bg-gradient-to-r from-pink-600 to-blue-600 z-[99999]",
                style: {
                    scaleX,
                    transformOrigin: "0%"
                }
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(HeroSection, {}),
            /*#__PURE__*/ jsx_runtime_.jsx(ServiceSection, {}),
            /*#__PURE__*/ jsx_runtime_.jsx(FeaturesSection, {}),
            /*#__PURE__*/ jsx_runtime_.jsx(HowItWorks, {}),
            /*#__PURE__*/ jsx_runtime_.jsx(FAQSection, {})
        ]
    });
}


/***/ }),

/***/ 78159:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   $$typeof: () => (/* binding */ $$typeof),
/* harmony export */   __esModule: () => (/* binding */ __esModule),
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var next_dist_build_webpack_loaders_next_flight_loader_module_proxy__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(61363);

const proxy = (0,next_dist_build_webpack_loaders_next_flight_loader_module_proxy__WEBPACK_IMPORTED_MODULE_0__.createProxy)(String.raw`S:\Web Applications\NextJS\YenSMS\src\app\page.tsx`)

// Accessing the __esModule property and exporting $$typeof are required here.
// The __esModule getter forces the proxy target to create the default export
// and the $$typeof value is for rendering logic to determine if the module
// is a client boundary.
const { __esModule, $$typeof } = proxy;
const __default__ = proxy.default;


/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (__default__);

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [3587,8425,2533,9056], () => (__webpack_exec__(98381)));
module.exports = __webpack_exports__;

})();